function [Du, invalid] = acc3(imBot, imTop, downsample_factor, saveFlag, outDir)
    imBot = im2double(rgb2gray(imBot));
    imTop = im2double(rgb2gray(imTop));
    if downsample_factor ~= 1
        imBot = imresize(imBot, downsample_factor);
        imTop = imresize(imTop, downsample_factor);
    end
    s = size(imTop);
    dm = 40;
    winSize = 8;
    dtol = 5;

    fprintf('\nSetting Up Accumulator...');
    % Set up Accumulator, d = 1 = disparity of 0
    acc = zeros(s(1), s(2), dm);
    for i = 0:dm
        imT = imtranslate(imTop, [0, -i]);
        acc(:,:,i+1) = abs(imT - imBot);
    end

    acc_s = size(acc);
    % h = fspecial('average', [winSize, winSize]);
    h = ones(winSize, winSize);
    acc_av = zeros(acc_s);
    for i = 1:dm+1
        acc_av(:,:,i) = imfilter(acc(:,:,i), h);
    end
    acc = acc_av;


    invalid = zeros(acc_s(1), acc_s(2));
    lenth = 3;
    Du = zeros(acc_s(1), acc_s(2));
    Dd = zeros(acc_s(1), acc_s(2));
    % Set up initial disparity map
    fprintf('\nCalculating Disparity...');
    fprintf(repmat('\t', [1, 12]));
    for i = 1:s(1)
        fprintf(strcat(repmat('\b', [1, 11]), '%4d / %4d'), i, s(1));
        for j = 1:s(2)
            t = max(i - lenth, 1);
            l = max(j - lenth, 1);
            r = min(j + lenth, s(2));
            b = min(i + lenth, s(1));
            minErr = 99999;
            minD = 0;
            for d = 1:dm+1
                window = acc(t:b, l:r, d);
                err = norm(window(:));
                if(err - minErr < -0.5)
                    minD = d - 1;
                    minErr = err;
                end
            end
            Du(i, j) = minD;
            if(var(acc(i, j, :)) < 0.1)
                invalid(i, j) = 1;
            end
        end
    end
    
    if downsample_factor ~= 1
        Du = imresize(Du, 1/downsample_factor);
        invalid = imresize(invalid, 1/downsample_factor);
        Du = Du / downsample_factor;
    end
    if saveFlag == 1
        save(strcat(outDir, 'raw_disp.mat'), 'Du', 'invalid');
    end
end