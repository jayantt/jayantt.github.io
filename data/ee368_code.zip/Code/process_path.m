function out = process_path(path)
    if (path(end) ~= '/') && (path(end) ~= '\')
        path = strcat(path, '/');
    end
    out = path;
end