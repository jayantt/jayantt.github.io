% Extracts features based on image gradients
function sub_f = gradient_features(im, window_size)
    [gx, gy] = get_gradients(im);
    features = sqrt(gx.^2+gy.^2);
    sub_f = max_sample(features, window_size);
end