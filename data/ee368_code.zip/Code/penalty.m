function y = penalty(x, a)
    y = 2*abs(x/a)./(1+abs(x/a));
end