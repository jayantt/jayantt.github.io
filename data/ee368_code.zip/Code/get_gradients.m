% Computes X and Y gradients of an image
function [gradx, grady] = get_gradients(im)
    im = im2double(im);
    lim = size(im);
    gradx = zeros(lim);
    grady = zeros(lim);
    gradx(2:end-1, :, :) = (im(3:end, :, :)-im(1:end-2, :, :))/2;
    gradx(1, :, :) = im(2, :, :)-im(1, :, :);
    gradx(end, :, :) = im(end, :, :)-im(end-1, :, :);
    grady(:, 2:end-1, :) = (im(:, 3:end, :)-im(:, 1:end-2, :))/2;
    grady(:, 1, :) = im(:, 2, :)-im(:, 1, :);
    grady(:, end, :) = im(:, end, :)-im(:, end-1, :);
end