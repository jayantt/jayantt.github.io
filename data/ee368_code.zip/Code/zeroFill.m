function [ testIm ] = zeroFill( im2, thresh )
[post, num] = bwlabel(im2 == 0);
testIm = im2;
for i = 1:num
    reg = post == i;
    if(sum(reg(:)) < thresh)
        str = strel('line', 10, 90);
        dilReg = imdilate(reg, str);
        edge = xor(dilReg, reg);
%         val = sum(sum(testIm(edge)))/(sum(sum(edge)));
        mat = testIm(edge);
        val = median(mat(:));
        testIm(reg) = val;
    end
end

end

