% Sharpens a given image using morphological processing
function out = sharpen(im, kernel_size, iter)
    c = (kernel_size+1)/2;
    w = zeros(kernel_size);
    for i=1:kernel_size
        for j=1:kernel_size
            if (i-c)^2+(j-c)^2 <= (kernel_size-c)^2
                w(i, j) = 1;
            end
        end
    end
    for i=1:iter
        im_d = imdilate(im, w);
        im_e = imerode(im, w);
        im_h = 0.5*(im_d+im_e);
        im_out = im;
        im_out(im>=im_h) = im_d(im>=im_h);
        im_out(im<im_h) = im_e(im<im_h);
        im = im_out;
    end
    out = im;
end