% Extracts features based on image intensity
function sub_f = intensity_features(im, window_size)
    im = im2double(im);
    lim = size(im);
    lim(1) = lim(1)/window_size;
    lim(2) = lim(2)/window_size;
    sub_f = zeros(lim(1), lim(2), 3);
    for i=1:lim(1)
        for j=1:lim(2)
            sub_f(i, j, :) = sum(sum(im((i-1)*window_size+(1:window_size), (j-1)*window_size+(1:window_size), :), 1), 2)/(window_size^2);
        end
    end
end