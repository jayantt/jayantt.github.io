function features = window_features(im, window_size)
    im = im2double(im);
    lim = size(im);
    features = zeros(window_size, window_size, lim(3), lim(1)/window_size, lim(2)/window_size);
    for i=1:lim(1)/window_size
        for j=1:lim(2)/window_size
            features(:, :, :, i, j) = im((i-1)*window_size+(1:window_size), (j-1)*window_size+(1:window_size), :);
        end
    end
end