% Finds out which of the two images was taken from a higher viewpoint and
% whihc one was taken from a lower viewpoint
function direction = get_upper_lower(im1, im2)
    im{1} = im1;
    im{2} = im2;
    lim = size(im{1});
    v = zeros(2, lim(1));
    for i=1:2
        v(i, :) = sum(sum(im{i}, 3), 2);
    end
    max_shift = 20;
    score = zeros(2*max_shift+1, 1);
    for i=1:2*max_shift+1
        shift = i-1-max_shift; % Positive is up
        if shift > 0
            shifted = cat(2, v(2, 1+shift:end), v(2, 1:shift));
        elseif shift < 0
            shifted = cat(2, v(2, lim(1)+shift+1:end), v(2, 1:lim(1)+shift));
        else
            shifted = v(2, :);
        end
        score(i) = sum(v(1, :).*shifted)/sqrt(sum(v(1, :).^2)*sum(v(2, :).^2));
    end
    score = score-wrev(score);
    score = sign(sum(score(2:end)-score(1:end-1)));
    direction = [-score; score];
end