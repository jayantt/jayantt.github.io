function [IR] = RGBD_inpaint(IR,DR)

disp('Performing Inpainting')
tic

pad_ratio = 1/16;
pad = round(pad_ratio*size(IR,2));

IR = padarray(IR, [0 pad 0], 'symmetric');
DR = padarray(DR, [0 pad 0], 'symmetric');

fillmask = zeros(size(DR));

for i=1:size(IR,1)
    for j=1:size(IR,2)
        if(IR(i,j,:) == 0)
            k = j;
            while k <= size(IR,2) && prod(IR(i,k,:) == 0) == 1
                fillmask(i,k) = 1;
                k = k + 1;
            end
            k = k - 1;
            if 2*k-j+1 <=size(IR,2) && j > 1 && DR(i,k+1) > DR(i,j-1) 
                IR(i,j:k,:) = flip(IR(i,k+1:2*k-j+1,:),1);
            elseif 2*j-k-1 > 0 && k < size(DR,2) && DR(i,k+1) < DR(i,j-1)
                IR(i,j:k,:) = flip(IR(i,2*j-k-1:j-1,:),1);
            end
        end
        j = j - 1;
    end
end

IR = imrotate(IR,90);
DR = imrotate(DR,90);
fillmask = imrotate(fillmask,90);

for i=1:size(IR,1)
    for j=1:size(IR,2)
        if(IR(i,j,:) == 0)
            k = j;
            while k <= size(IR,2) && fillmask(i,k) == 1
                k = k + 1;
            end
            k = k - 1;
            if 2*k-j+1 <=size(IR,2) && j > 1 && DR(i,k+1) > DR(i,j-1) 
                IR(i,j:k,:) = flip(IR(i,k+1:2*k-j+1,:),1);
            elseif 2*j-k-1 > 0 && k < size(DR,2) && DR(i,k+1) < DR(i,j-1)
                IR(i,j:k,:) = flip(IR(i,2*j-k-1:j-1,:),1);
            end
        end
        j = j - 1;
    end
end

IR = imrotate(IR,-90);
%DR = imrotate(DR,-90);

IR = IR(:,pad+1:size(IR,2)-pad,:);
%DR = DR(:,pad+1:size(DR,2)-pad,:);

disp(['Finished in ' num2str(toc) ' seconds'])