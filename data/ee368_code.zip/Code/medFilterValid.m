function [ outputIm ] = medFilterValid( im, valid )
window = 7;

im_size = size(im);
offset = floor(window/2);
outputIm = zeros(im_size(1), im_size(2));

for i = 1:im_size(1)
    for j = 1:im_size(2)
        t = max(i - offset, 1);
        l = max(j - offset, 1);
        r = min(j + offset, im_size(2));
        b = min(i + offset, im_size(1));
        win = (im(t:b, l:r));
        winValid = valid(t:b, l:r);
        if(sum(winValid(:)) == 0)
            outputIm(i, j) = median(win(:));
        else
            outputIm(i, j) = median(win(winValid == 1));
        end
    end
end
