function [IR,IL,DR,DL] = make_stereo(I,depth)

    delta = 20;

    [X, Y] = meshgrid(1:size(I,2),1:size(I,1));

    R = reshape(I(:,:,1),1,[]);
    G = reshape(I(:,:,2),1,[]);
    B = reshape(I(:,:,3),1,[]);
    D = reshape(depth,1,[]);
    X = reshape(X,1,[]);
    Y = reshape(Y,1,[]);

    RGBD = [R; G; B; D; X; Y];

    sortrows(RGBD,4);

    IR = zeros(size(I));
    DR = zeros(size(I,1),size(I,2));
    IL = zeros(size(I));
    DL = zeros(size(I,1),size(I,2));

    for i = 1:size(RGBD,2)
        i1 = round(X(i) + delta/(D(i)+1));
        i2 = Y(i);
        if(i1 > 0 && i1 < size(I,2))
            IR(i2,i1,:) = [R(i) G(i) B(i)];
            DR(i2,i1) = D(i);
        end

        i1 = round(X(i) - delta/(D(i)+1));
        i2 = Y(i);
        if(i1 > 0 && i1 < size(I,2))
            IL(i2,i1,:) = [R(i) G(i) B(i)];
            DL(i2,i1) = D(i);
        end
    end