function [Iout, Dout] = make_view(I1,depth1, e)
    
    e = -e;

    disp('Calculating new view...')
    tic
    
    %Limit to forward 180 degrees
    I = I1(:,round(size(I1,2)/4):round(size(I1,2)/4*3),:);
    depth = depth1(:,round(size(depth1,2)/4):round(size(depth1,2)/4*3));
    
    %Calculate Stuff
    [X, Y] = meshgrid(-90:180/size(I,2):90-180/size(I,2),1:size(I,1));
    R = reshape(I(:,:,1),1,[]);
    G = reshape(I(:,:,2),1,[]);
    B = reshape(I(:,:,3),1,[]);
    D = reshape(depth,1,[]);
    X = reshape(X,1,[]);
    Y = reshape(Y,1,[]);
    
    RGBD = [R; G; B; D; X; Y];
    sortrows(RGBD,4);

    Iout = zeros(size(I));
    Dout = zeros(size(I,1),size(I,2));

    old_angle = 90 - X;
    new_angle = atan2d(D.*sind(old_angle),(D.*cosd(old_angle)-e))-90;
    new_angle(isnan(abs(new_angle))) = 0;
    %new_dist = D.^2*(cosd(old_angle).^2 + sind(old_angle).^2).^(1/2);
    new_dist = D;
    i1 = round((new_angle+90)*size(I,2)/180)+1;
    i2 = Y;
    
    for i = 1:size(RGBD,2)
        Iout(i2(i),i1(i),:) = [R(i) G(i) B(i)];
        Dout(i2(i),i1(i)) = new_dist(i);
    end
    
    disp(['Finished in: ' num2str(toc) ' seconds'])