% Aligns images by shifting the second image horizontally and cyclically
% to achieve maximum correlation between images
function [out1, out2] = horizontal_align(im1, im2, debug)
    if nargin<3
        debug = 0;
    end
    im = cell(2, 1);
    im{1} = im1;
    im{2} = im2;
    lim = size(im{1});
    hor = zeros(2, lim(2));
    max_shift = 20;
    for i=1:2
        hor(i, :) = sum(sum(im{i}, 3), 1);
    end
    score = zeros(2*max_shift+1, 1);
    for i=1:2*max_shift+1
        shift = (i-1-max_shift);
        if shift > 0
            shifted = cat(2, hor(2, 1+shift:end), hor(2, 1:shift));
        elseif shift < 0
            shifted = cat(2, hor(2, lim(2)+shift+1:end), hor(2, 1:lim(2)+shift));
        else
            shifted = hor(2, :);
        end
        score(i) = sum((hor(1, :).*shifted))/sqrt(sum(hor(1, :).^2)*sum(hor(2, :).^2));
    end
    [max_score, idx] = max(score);
    opt_shift = idx-1-max_shift;
    if debug == 1
        figure;
        plot(-max_shift:max_shift, score);
        hold on;
        plot(opt_shift, max_score, 'r*');
        title('Determining Optimum Horizontal Shift');
        legend('Curve', 'Optimum Point', 'Location', 'south', 'Orientation', 'horizontal');
        xlabel(sprintf('Shift; Optimum = %d', opt_shift));
        ylabel('Correlation');
        grid on;
    end
    out1 = im1;
    if opt_shift > 0
        out2 = cat(2, im2(:, 1+opt_shift:end, :), im2(:, 1:opt_shift, :));
    elseif opt_shift < 0
        out2 = cat(2, im2(:, lim(2)+opt_shift+1:end, :), im2(:, 1:lim(2)+opt_shift, :));
    else
        out2 = im2;
    end
end