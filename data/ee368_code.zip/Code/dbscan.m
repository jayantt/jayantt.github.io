function out = dbscan(im, sensitivity, f, max_clusters, saveFlag, outDir, debug)
    fprintf('\nSegmenting image...');
    im = im2double(im);
    f = 1/f;
    im = imresize(im, 1/f);
    lim = size(im);
    r = im(:, :, 1);
    g = im(:, :, 2);
    b = im(:, :, 3);
    if (debug == 1) || (saveFlag == 1)
        R = zeros(lim(1:2));
        G = zeros(lim(1:2));
        B = zeros(lim(1:2));
    end
    clusters = zeros(lim(1), lim(2));
    foundAll = 0;
    fprintf(repmat('\t', [1, 12]));
    for i=1:max_clusters
        fprintf(strcat(repmat('\b', [1, 11]), '%4d / %4d'), i, max_clusters);
        if isempty(find(clusters==0, 1))
            foundAll = 1;
            break
        end
        start = datasample(find(clusters==0), 1);
        clusters(start) = 1;
        clusters = get_cluster(r, g, b, lim, clusters, sensitivity-0.001*i);
        if (debug == 1) || (saveFlag == 1)
            R(clusters==1) = mean(mean(r(clusters==1)));
            G(clusters==1) = mean(mean(g(clusters==1)));
            B(clusters==1) = mean(mean(b(clusters==1)));
        end
        clusters(clusters==1) = -i;
    end
    fprintf(strcat(repmat('\b', [1, 11]), '%4d / %4d'), max_clusters, max_clusters);
    if foundAll ~= 1
        fprintf('\nWARNING: dbscan: %d clusters were not enough to cover the entire image', max_clusters);
    end
    fprintf('\nCreated %d segments', i);
    if debug == 1
        seg_im = cat(3, R, G, B);
        figure;
        imshow(seg_im, []);
    end
    if saveFlag == 1
        seg_im = cat(3, R, G, B);
        save(strcat(outDir, 'segmentation.mat'), 'seg_im', 'clusters');
    end
    out = clusters;
end