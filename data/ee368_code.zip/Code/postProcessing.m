[post, num] = bwlabel(im2 == 0);
testIm = im2;
for i = 1:num
    reg = post == i;
    str = strel('disk', 4);
    dilReg = imdilate(reg, str);
    edge = xor(dilReg, reg);
    val = sum(sum(testIm(edge)))/(sum(sum(edge)));
%     val = min(min(testIm(edge)));
    testIm(reg) = val;
end

