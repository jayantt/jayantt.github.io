function [ID] = disp_map(I1,I2)

    match_size = 8;
    stride = 4;

    ID = zeros(size(I1,1)/stride,size(I1,2)/stride);
    
    disp('Calculating Disparity')
    tic
    for i=1+match_size/2:stride:size(I1,2)-match_size/2
        search_region = I2(:,i-match_size/2:i+match_size/2,:);
        for j=1+match_size/2:stride:size(I1,1)-match_size/2
            search_kernel = I1(j-match_size/2:j+match_size/2,i-match_size/2:i+match_size/2,:);
            ID((j-1)/stride+1,(i-1)/stride+1) = -patch_match(search_region,search_kernel,j,stride);
        end
    end
    disp(['Finished in ' num2str(toc) ' seconds'])