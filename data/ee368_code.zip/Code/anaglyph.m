close all 
clear all

I = double(imread('Oculus_Image.png'))/255;
IR = I(1:size(I,1)/2,:,:);
IL = I(size(I,1)/2+1:size(I,1),:,:);

IL(:,:,1) = 0;
IR(:,:,2:3) = 0;

I3D = IR + IL;

imshow(I3D)

imwrite(I3D,'anaglyph.png');