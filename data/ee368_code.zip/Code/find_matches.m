% Find out which disparity matches are bidirectional
function [out1, out2] = find_matches(map1, map2)
    lim = size(map1);
    out1 = zeros(lim);
    out2 = zeros(lim);
    for j=1:lim(2)
        for i=1:lim
            if i == map2(map1(i, j), j)
                out1(i, j) = 1;
            end
            if i == map1(map2(i, j), j)
                out2(i, j) = 1;
            end
        end
    end
end