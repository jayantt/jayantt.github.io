% Downsamples a given image choosing the maximum value as representative
% for each subregion
function out = max_sample(im, window_size)
    lim = size(im);
    lout = lim;
    lout(1:2) = lout(1:2)/window_size;
    out = zeros(lout);
    for i=1:lout(1)
        for j=1:lout(2)
            if length(lout) == 3
                out(i, j, :) = max(max(im(window_size*(i-1)+(1:window_size), window_size*(j-1)+(1:window_size), :)));
            else
                out(i, j) = max(max(im(window_size*(i-1)+(1:window_size), window_size*(j-1)+(1:window_size))));
            end
        end
    end
end