function [I2] = oculus_resize(I1)

    final_res = [960, 1080];
    horz_fov = 90;
    vert_fov = final_res(1)/final_res(2)*horz_fov;
  
    %Calculate dimensions, pixels
    WW = size(I1,2)/360*horz_fov;
    HH = size(I1,1)/180*vert_fov;
    middle = [size(I1,1)/2 size(I1,2)/2];
    
    %Crop based on field of view
    I2 = I1(round(middle(1)-HH/2):round(middle(1)+HH/2),round(middle(2)-WW/2):round(middle(2)+WW/2),:);
    
    %Resize
    I2 = imresize(I2, [final_res(1) final_res(2)]);