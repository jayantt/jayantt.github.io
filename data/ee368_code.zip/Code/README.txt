Find below, all the relevant code files that were used in this project. Indentation indicates that the indented file is called by the parent file.
Abbr: UCS = User Configurable Section of the main file.
Note: Not all functions given below need to be used while running the main file. The UCS has several switches to turn on and off calling of different modules

---

main % Top level file
	process_path % Processes paths given in UCS
	get_upper_lower % Auto-detects which of the two input images is from a high viewpoint
	horizontal_align % Aligns the input images
	acc3 % Implements accumulator-based raw disparity computation
	post_processing % High level function that does various post-processing on raw disparity
		zeroFill % Removes sections of disparity map if the corresponing region of RGB image has low variance
		wallFill % Fills in holes in disparity map
	dbscan % High level function that achieves image segmentation
		get_cluster % Grows a segment, starting from a given pixel
			update_nbrs % Helper function
			clean % Helper function
	segment_disparity % Implements segmentation-based disparity averaging
	weighted_median % Weighted median filtering of disparity
	disp_to_dist % Converts disparity to distance
	bilateral_filter % Runs edge-preseving smoothing operation on the distance map
	depth_filter % Runs another edge-preserving smoothing operation on the distance map
	make_stereo % Renders true stereo view
	make_view_oculus % Render stereo view of viewing in Oculus
	RGBD_inpaint % Performs inpainting in the rendered view
	medianfilter % Median filtering on the final output view
[anaglyph] % Creates an anaglyph from the rendered stereo image.

---
