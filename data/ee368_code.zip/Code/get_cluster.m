function out = get_cluster(r, g, b, lim, clusters, threshold)
    while ~isempty(find(clusters==1, 1))
        [x, y] = find(clusters==1, 1);
        clusters = update_nbrs(clusters, [x, y], lim(1:2));
        clusters = clean(clusters, [x, y], threshold, r, g, b);
        clusters(x, y) = 2;
    end
    clusters(clusters==2)=1;
    clusters = imerode(imdilate(clusters, ones(3)), ones(3));
    %clusters = imdilate(imerode(clusters, ones(3)), ones(3));
    out = clusters;
end