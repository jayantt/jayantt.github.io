function out = suppress_max(im, threshold)
    lim = size(im);
    [u, v] = find(im>threshold);
    out = im;
    for i=1:length(u)
        out(u(i), v(i)) = (sum(sum(im(max(u(i)-1, 1):min(u(i)+1, lim(1)), max(v(i)-1, 1):min(v(i)+1, lim(2)))))-im(u(i), v(i)))/8;
    end
end