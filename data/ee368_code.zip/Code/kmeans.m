% K-means clustering (based on colour) implementation for images
function class = kmeans(im, k)
    im = im2double(im);
    lim = size(im);
    r = im(:, :, 1);
    g = im(:, :, 2);
    b = im(:, :, 3);
    R = r;
    G = g;
    B = b;
    class = zeros(lim(1), lim(2));
    numIter = 10;
    means = rand(k, 3);
    for z = 1:numIter
        temp = zeros(lim(1), lim(2), k);
        for i=1:k
            v = reshape(means(i, :), [1, 1, 3]);
            temp(:, :, i) = sum((repmat(v, [lim(1), lim(2), 1])-im).^2, 3);
        end
        temp = double(temp==repmat(min(temp, [], 3), [1, 1, k]));
        for i=1:k
            temp(:, :, i) = i*temp(:, :, i);
        end
        class = sum(temp, 3);
        for i=1:k
            R(class==i)=means(i, 1);
            G(class==i)=means(i, 2);
            B(class==i)=means(i, 3);
            out = cat(3, R, G, B);
        end
        imshow(out, [0 1]);
        drawnow;
        for i=1:k
            means(i, 1) = mean(r(class==i));
            means(i, 2) = mean(g(class==i));
            means(i, 3) = mean(b(class==i));
        end
    end