function out = clean(clusters, threshold, r, g, b)
    out = clusters;
    temp = zeros(size(clusters));
    temp(clusters==1)=1;
    imdilate(temp, ones(3, 3));
    ids = find((temp==1) & (clusters>0));
    vec = sum([r(ids), g(ids), b(ids)], 1)/length(find(ids));
    nbr = find(clusters == -1);
    dist_sq = sum(([r(nbr), g(nbr), b(nbr)]-repmat(vec, [length(nbr), 1])).^2, 2);
    pos = dist_sq <= threshold^2;
    neg = dist_sq > threshold^2;
    out(nbr(pos)) = 1;
    out(nbr(neg)) = 0;
end