% Top level function that computes disparity maps for two 360 images
%% Reading Images
fprintf('Reading images...');
im{1} = im2double(imread('F:/EE 368/Project/Images/R0010003.jpg'));
im{2} = im2double(imread('F:/EE 368/Project/Images/R0010004.jpg'));

%% Horizontal Align
fprintf('\nAligning images...');
[im{1}, im{2}] = horizontal_align(im{1}, im{2});

%% Determining Image with Higher Viewpoint
fprintf('\nIdentifying viewpoints...');
direction = get_upper_lower(im{1}, im{2});

%% Get Features
fprintf('\nExtracting features...');
sub_f = cell(2, 1);
window_size = 8;
max_shift = inf;
for i=1:2
    sub_f{i} = window_features(im{i}, window_size);
end

%% Bidirectional Feature Matching
fprintf('\nRunning bidirectional feature matching...');
lim = size(im{1});
sub_lim = [lim(1)/window_size, lim(2)/window_size];
d = cell(2, 1);
d{1} = zeros(sub_lim);
d{2} = zeros(sub_lim);

numIter = 2;
max_count = numIter*sub_lim(2);
fprintf(repmat('\t', [1, 12]));

for m=1:2
    for j=1:sub_lim(2)
        count = (m-1)*sub_lim(2)+j;
        fprintf(strcat(repmat('\b', [1, 11]), '%4d / %4d'), count, max_count);
        for i=1:sub_lim(1)
            if direction(m) == 1
                range = [max(1, i-max_shift), i];
            else
                range = [i, min(i+max_shift, sub_lim(1))];
            end
            d{m}(i, j) = nearest_neighbour(sub_f{m}, sub_f{3-m}, j, i, range);
        end
    end
end
fprintf('\nRefining computed disparity map...');
matches = cell(2, 1);
[matches{1}, matches{2}] = find_matches(d{1}, d{2});

r = cell(2, 1);
for i=1:2
    r{i} = get_range(d{i}, matches{i});
end

for z = 1:numIter
    fprintf('\n\tIteration %d of %d...', z, numIter);
    max_count = numIter*sub_lim(2);
    fprintf(repmat('\t', [1, 12]));
    for m=1:2
        for j=1:sub_lim(2)
            count = (m-1)*sub_lim(2)+j;
            fprintf(strcat(repmat('\b', [1, 11]), '%4d / %4d'), count, max_count);
            for i=1:sub_lim(1)
                if direction(m) == 1
                    range = [max(1, i-max_shift), i];
                else
                    range = [i, min(i+max_shift, sub_lim(1))];
                end
                if r{m}(i, j, 1) <= r{m}(i, j, 2)
                    range(1) = max(range(1), r{m}(i, j, 1));
                    range(2) = min(range(2), r{m}(i, j, 2));
                end
                d{m}(i, j) = nearest_neighbour(sub_f{m}, sub_f{3-m}, j, i, range);
            end
        end
    end
    matches = cell(2, 1);
    [matches{1}, matches{2}] = find_matches(d{1}, d{2});
    for i=1:2
        r{i} = get_range(d{i}, matches{i});
    end
end
disp = cell(2, 1);
for i=1:2
    disp{i} = suppress_max(abs(d{i}-repmat((1:sub_lim(1))', [1, sub_lim(2)])), 20);
end

%% Image Segmentation
fprintf('\nRunning image segmentation...');
clusters = cell(2, 1);
for i=1:2
    fprintf('\n\tImage %d of %d:', i, 2);
    fprintf('\n\t\t');
    clusters{i} = -dbscan(im{i}, 4.3);
end

%% Improving Disparity Map
fprintf('\nImproving disparity using segmentation results...');
fprintf('\n\tComputing local variances...');
v = cell(2, 1);
for i=1:2
    v{i} = get_variance(sub_f{i});
end
fprintf('\n\tUpdating disparity maps...');
for i=1:2
    disp{i} = segment_disparity(clusters{i}, disp{i}, v{i});
end
fprintf('\nScaling disparity maps to full resolution');
for i=1:2
    disp{i} = imresize(disp{i}, window_size);
    disp{i} = round(window_size*disp{i});
end
imshow(disp{1}, []);

%% Writing Output Files
fprintf('\nWriting output files...');
save('clusters.mat', 'clusters');
save('disp.mat', 'disp');
fprintf('\nAll done.\n');