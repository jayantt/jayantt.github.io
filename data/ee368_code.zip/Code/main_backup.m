clear all
close all

%Read the images
%I1 = double(imread('images\R0010003.JPG'))/255;
%I2 = double(imread('images\R0010004.JPG'))/255;
load('colorImages.mat');
%I1 = repmat(imBot,[1,1,3]);
%I2 = repmat(imTop,[1,1,3]);
I1 = imBot;
I2 = imTop;
%Align, Jayant's method
[I1,I2] = horizontal_align(I1,I2);

%Resize for speed (?)
resize_factor = 1;
I1 = imresize(I1,resize_factor);
I2 = imresize(I2,resize_factor);

%Calculate Disparity 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOAD DISPARITY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%disparity = load('disp_data.mat');
load('seg_disp.mat');
disp = out;
factor = size(I1,1)/size(disp,1);
disp = imresize(disp, [size(I1,1) size(I1,2)]);
disp = (disp*factor);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%SET CAMERA OFFSET!!!!!!!!!!!!!!!!!!!!!!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta = 0.1; %Distance between cameras, just guess it

%Smooth disparity
%OR NOT
%disp = weighted_median(disp);

%Calculate Depth Channel
D = disp_to_dist(disp,delta);

%Misc Corrections
D(isinf(abs(D))) = -1;
D(isnan(abs(D))) = -1;
D(D == -1) = max(D(:));
D(D < 0) = max(D(:));

%Bilateral Filtering
%D = bilateral_filter(I1,D);

%Filter crap

sz = 161;
K = fspecial('gaussian',sz,sz/6);
K(1:(sz-1)/2,:) = 0;
K(:,1:(sz-1)/2) = 0;
K = K/sum(K(:));
D = conv2(D,K,'same');
%{
%}

%Resize depth map to images, if it's not that size already
D = imresize(D,[size(I1,1) size(I1,2)]);

%Generate Stereo Views
%[IR,IL,DR,DL] = make_stereo(I1,D);

[IL,DL] = make_view_oculus(I1,D,0-.06);
[IR,DR] = make_view_oculus(I1,D,0+.06);

%Perform Inpainting
IL = RGBD_inpaint(IL,DL);
IR = RGBD_inpaint(IR,DR);

%Median Filter for looks
%OR NOT
%IL = medianfilter(IL,5);
%IR = medianfilter(IR,5);

%Convert to Oculus FOV and resolution
%IL = oculus_resize(IL);
%IR = oculus_resize(IR);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%PLOTTING AND OUTPUT CODE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure
subplot(1,2,2)
imshow(IR)
imwrite(IR,'IR.jpg')
title('Right Image')
subplot(1,2,1)
imshow(IL)
imwrite(IL,'IL.jpg')
title('Left Image')

imwrite(cat(1,IR,IL),'Oculus_Image.png');

imwrite(D/max(D(:)),'D.png')

figure
imshow(D/max(D(:)))
title('Depth Map')

disp = abs(disp);
disp2 = (disp-min(disp(:)))/(max(disp(:))-min(disp(:)));

figure
imshow(disp2)
title('Disparity Map')

imwrite(disp2,'disp.png');
%{
%}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%RANDOM UNUSED CODE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%I1 = imresize(I1,1/16);
%I2 = imresize(I2,1/16);

%D1 = double(imread('images\Disparity_03_04.png'))/255;
%S1 = double(imread('images\Segmented_03.png'))/255;

%D1 = D1(77:634,210:1322);
%S1 = S1(31:628,85:1279);

%D1 = imresize(D1,size(S1));

%{
figure
subplot(1,2,1)
imshow(D1)

subplot(1,2,2)
imshow(S1)

figure
imshow((S1+D1)/2)
%}

%{
NS = unique(S1);
for i=1:length(NS)
    mask{i} = S1;
    mask{i}(mask{i} ~= NS(i)) = 0;
    mask{i} = mask{i}/max(mask{i}(:));
end


M = mask{118};
D2 = D1.*M;

figure
subplot(1,2,1)
imshow(D2)

D2 = imdilate(D2,ones(10));
D2 = medfilt2(D2,[10,10]);
%K = fspecial('gaussian',21,7);
K = fspecial('average',100);
D2 = conv2(D2,K,'same');

D2 = D2.*M;
subplot(1,2,2)
imshow(D2)



for i=1:length(mask)
    
    
    
    
end



%out = dbscan(I1, 0.05)


%}


%Align
%{
L1 = sum(rgb2gray(I1));
L2 = sum(rgb2gray(I2));
F1 = fftshift(fft(L1));
F2 = fftshift(fft(L2));
A1 = atan2(real(F1),imag(F1));
A2 = atan2(real(F2),imag(F2));
A3 = A1-A2;
%}

%{
%Generate views
E1 = -.04; %One eye (m)
E2 = .04; %Other eye (m)
dH = 0.23; %Height delta

[A, E] = meshgrid(linspace(-180,180-1/size(I1,2),size(I1,2)),linspace(-90,90,size(I1,1)));

Amask = A;
Amask(abs(Amask) > 90) = 0;
Amask(Amask ~= 0) = 1;

MI1 = I1;
MI1(:,:,1) = MI1(:,:,1).*Amask;
MI1(:,:,2) = MI1(:,:,2).*Amask;
MI1(:,:,3) = MI1(:,:,3).*Amask;

imshow(MI1)
%}

%{
I = double(imread('image_color/learn34.png'))/255;
depth = double(imread('disparity/learn34.png'))/255;

[IR,IL,DR,DL] = make_stereo(I,depth);

IL = inpaint(IL,DL);
IR = inpaint(IR,DR);

IL = medianfilter(IL,3);
IR = medianfilter(IR,3);

figure
subplot(1,2,1)
imshow(IR)
imwrite(IR,'IR.png')
subplot(1,2,2)
imshow(IL)
imwrite(IL,'IL.png')
%}


%{


I = double(imread('image_color/learn34.png'))/255;
depth = double(imread('disparity/learn34.png'))/255;

K = fspecial('gaussian',6,1);
I2 = convn(I,K,'same');

dx = [1 0 -1; 1 0 -1]/2;
dy = dx';
dxy = [0 0 1; 0 0 0; -1 0 0];
dyx = [1 0 0; 0 0 0; 0 0 -1];

Ix = convn(I2,dx,'same');
Iy = convn(I2,dy,'same');
Ixy = convn(I2,dxy,'same');
Iyx = convn(I2,dyx,'same');
Ixy = sum((Ix.^2 + Iy.^2 + Ixy.^2 + Iyx.^2),3).^(1/2);

Id = Ixy;
t = 0.05;
Id(Id < t) = 0;
Id(Id ~= 0) = 1;

figure
imshow(Id)
%}


%I1 = imresize(I1,1/4);
%I2 = imresize(I2,1/4);







