function [Iout] = depth_filter(D,sz)

    %pad_ratio = 1/16;
    pad = round((sz-1)/2);

    D = padarray(D, [0 pad], 'symmetric');
    D = padarray(D, [pad 0], 'replicate');

    K = fspecial('gaussian',sz,sz/6);
    K(1:(sz-1)/2,:) = 0;
    K(:,1:(sz-1)/2) = 0;
    K = K/sum(K(:));
    D = conv2(D,K,'same');
    
    Iout = D(pad+1:size(D,1)-pad,pad+1:size(D,2)-pad);