function I = medianfilter(I,s)
    I(:,:,1) = medfilt2(I(:,:,1),[s s]);
    I(:,:,2) = medfilt2(I(:,:,2),[s s]);
    I(:,:,3) = medfilt2(I(:,:,3),[s s]);