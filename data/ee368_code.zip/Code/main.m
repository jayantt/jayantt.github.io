%% User Configurable Part
% Reading Images
readLoad = 0; % Load if zero, read if one
imageFolder = '../Images';
imageMat = 'disparity_auditorium4.mat'; % Images to be loaded (if readLoad is zero)
images = {'R0010003.JPG', 'R0010004.JPG'}; % Images to be read (if readLoad is 1)
autoDetectUpperLower = 1; % Automatically detects which image viewpoints
upper = 2; % (1 or 2) Manually indicate index of the upper viewpoint image (if readLoad is 1)
align_debug = 0;

% Run Parameters
% CAUTION: Use of global resize factor is not recommended.
% Instead use downsample factors for individual functions.
resize_factor = 1; %Downsampling factor for images. Takes values between 0 and 1. Smaller value implies poorer quality, faster execution

% Disparity parameters
disp_calcLoad = 0; % Load if zero, calculate if one
disp_pp_calcLoad = 0; % Load if zeros, calculate if one
dispFolder = '../Images';
rawDispMat = 'raw_disp.mat';
dispMat = 'disparity_auditorium4.mat';
saveDispFlag = 1; % Saves disparity values in .mat file
disp_outDir = '../Output';
dispDebug = 1; % Debug disparity calculator (if calcLoad is 1)
% CAUTION: Setting disp_downsample to one is recommended. 
% Other values are not tested yet. Might have bugs.
disp_downsample = 1; % Downsample image for disparity computation

% Segmentation (DBSCAN) parameters
dbscan_skip = 0; % If set, image segmentation
dbscan_calcLoad = 1; % Load if zero, calculate if one
dbscan_sensitivity = 5; % Higher sensitivity implies finer clusters, also more no. of clusters
dbscan_maxClusters = 4000;
dbscan_downsample = 1/8; % Between 0 and 1. Smaller is faster. This step is slow. Increasing this factor beyond 1/4 may result in large computation time.
dbscan_debug = 1; % Debug image segmenter 
dbscan_saveFlag = 1; % Saves image segments in .mat file
dbscan_outDir = '../Output';
segFolder = '../Images';
segMat = 'segmentation.mat';

% Segmented disparity parameters
seg_disp_saveFlag = 1; % Saves segmented disparity in a .mat file
seg_disp_outDir = '../Output';

% Disparity prefiltering parameters
pre_weighted_median_flag = 0;

% Distance computation parameters
delta = 0.1; %Distance between cameras, just guess it

% Post filtering parameters
post_bilateral_flag = 0;
post_quarter_gaussian_flag = 1;
depth_filt_sz = 161;

% Stereoview generation parameters
trueOculus = 0; % Oculus stereo if zero, True stereo if one
eye_dist = 0.12; % Distance between two eyes is 2*eye_dist in metres

% Output filtering parameters
med_filt_flag = 0;
med_filt_size = 5;

% Output directory for final results
final_outDir = '../Output';

% Warnings
show_MATLAB_warnings = 0;

%% Reading Inputs
if show_MATLAB_warnings == 0
    warning('off', 'all');
end
% Processing image directory path
imageFolder = process_path(imageFolder);
dispFolder = process_path(dispFolder);
segFolder = process_path(segFolder);
disp_outDir = process_path(disp_outDir);
dbscan_outDir = process_path(dbscan_outDir);
seg_disp_outDir = process_path(seg_disp_outDir);
final_outDir = process_path(final_outDir);

% Read / load images
if readLoad == 1
    for i=1:2
        images{i} = strcat(imageFolder, images{i});
    end
    im1 = imread(images{1});
    im2 = imread(images{2});
else
    imageMat = strcat(imageFolder, imageMat);
    load(imageMat);
    im1 = imBot;
    im2 = imTop;
    upper = 2;
end
% Determine viewpoint
if autoDetectUpperLower == 1
    upper_lower = get_upper_lower(im1, im2);
    upper = (3-upper_lower(1))/2;
end
% I1 is the bottom image; I2 is the top image
if upper == 1
    I1 = im2;
    I2 = im1;
else
    I1 = im1;
    I2 = im2;
end
% Clear temporary variables
clear im1 im2

%Horizontal Align
[I1,I2] = horizontal_align(I1,I2, align_debug);

%Resize images (for speed)
I1 = imresize(I1,resize_factor);
I2 = imresize(I2,resize_factor);

%%Calculate Disparity 
if disp_pp_calcLoad == 1
    if disp_calcLoad == 1
        [Du, invalid] = acc3(I1, I2, disp_downsample, saveDispFlag, disp_outDir);
    else
        load(strcat(dispFolder, rawDispMat));
    end
    finalOut = post_processing(Du, invalid, saveDispFlag, disp_outDir, dispDebug);
else
    load(strcat(dispFolder, dispMat));
end

disp = finalOut;
% Resize and scale disparity based on image size
factor = size(I1,1)/size(disp,1);
disp = imresize(disp, [size(I1,1) size(I1,2)]);
disp = (disp*factor);

%% Image Segmentation and Disparity Averaging
if dbscan_skip ~= 1
    if dbscan_calcLoad == 1
        clusters = -dbscan(I1, dbscan_sensitivity, dbscan_downsample, dbscan_maxClusters, dbscan_saveFlag, dbscan_outDir, dbscan_debug);
    else
        load(strcat(segFolder, segMat));
        clusters = -clusters;
    end
    disp = segment_disparity(clusters, disp, seg_disp_saveFlag, seg_disp_outDir);
end

%% Distance Computation
if pre_weighted_median_flag == 1
    disp = weighted_median(disp);
end

%Calculate Depth Channel
D = disp_to_dist(disp,delta);

%Misc Corrections
D(isinf(abs(D))) = -1;
D(isnan(abs(D))) = -1;
D(D == -1) = max(D(:));
D(D < 0) = max(D(:));

% Post-filtering
if post_bilateral_flag == 1
    D = bilateral_filter(I1,D);
end
if post_quarter_gaussian_flag == 1
    D = depth_filter(D,depth_filt_sz);
end

%Resize depth map to images, if it's not that size already
fprintf('\n');
D = imresize(D,[size(I1,1) size(I1,2)]);

%% Generate Stereo Views

if trueOculus == 1
    [IR,IL,DR,DL] = make_stereo(I1,D);
else
    [IL,DL] = make_view_oculus(I1,D,0-eye_dist);
    [IR,DR] = make_view_oculus(I1,D,0+eye_dist);
end

%% Perform Inpainting
IL = RGBD_inpaint(IL,DL);
IR = RGBD_inpaint(IR,DR);

%% Output Filtering
if med_filt_flag == 1
    IL = medianfilter(IL,med_filt_size);
    IR = medianfilter(IR,med_filt_size);
end

%% Output
figure
subplot(1,2,2)
imshow(IR)
imwrite(IR, strcat(final_outDir, 'IR.jpg'));
title('Right Image')
subplot(1,2,1)
imshow(IL)
imwrite(IL, strcat(final_outDir, 'IL.jpg'));
title('Left Image')

imwrite(cat(1,IR,IL), strcat(final_outDir, 'Oculus_Image.png'));
imwrite(D/max(D(:)), strcat(final_outDir, 'D.png'));

figure
imshow(D/max(D(:)))
title('Depth Map')

disp = abs(disp);
disp2 = (disp-min(disp(:)))/(max(disp(:))-min(disp(:)));

figure
imshow(disp2)
title('Disparity Map')

imwrite(disp2, strcat(final_outDir, 'disp.png'));