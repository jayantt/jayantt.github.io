function out = segment_disparity(clusters, disparity, saveFlag, outDir)
    lim = size(disparity);
    if size(clusters) ~= size(disparity)
        disparity = imresize(disparity, size(clusters));
    end
    out = disparity;
    n = max(clusters(:));
    for i=1:n
        if isempty(clusters==i)
            continue
        end
        temp = disparity(clusters==i);
        out(clusters==i) = mean(temp(temp>=0));
    end
    out = imresize(out, lim);
    if saveFlag == 1
        save(strcat(outDir, 'seg_disp.mat'), 'out');
    end
end