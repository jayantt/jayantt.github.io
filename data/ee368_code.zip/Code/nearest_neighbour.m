% Does a nearest neighbour search on the image features given a range along
% which to search for matches.
function match_id = nearest_neighbour(f1, f2, epi_id, source_id, target_range)
    src_im = f1(:, :, :, source_id, epi_id);
    lim = length(target_range(1):target_range(2));
    src = repmat(src_im, [1, 1, 1, lim]);
    tgt = f2(:, :, :, target_range(1):target_range(2), epi_id);
    score = reshape(sum(sum(sum((src-tgt).^2, 1), 2), 3), [1, lim]);
    score = score + penalty((target_range(1):target_range(2))-source_id, size(f1, 4));
    [~, match_id] = min(score);
    match_id = match_id+target_range(1)-1;
end