function [x] = patch_match(search, patch, position, stride)
    min_cost = -1;
    x = 0;
    b = 1/1000;
    HH = size(patch,1);
    WW = size(patch,2);
    error = 0;
    for i=1:stride:size(search,1)-HH+1
        for j=1:stride:size(search,2)-WW+1
            %if i==1
                delta = (search(i:i+HH-1,j:j+WW-1,:) - patch).^2;
                error = sum(delta(:));
            %else
                %prev = (search(i,j:j+WW-1,:) - patch(1,:,:)).^2;
                %next = (search(i+HH-1,j:j+WW-1,:) - patch(HH,:,:)).^2;
                %error = error - sum(prev(:)) + sum(next(:));
            %end
            cost = error + b*(i + (HH-1)/2-position)^2;
            if min_cost < 0 || cost < min_cost 
                min_cost = cost;
                x = i+ (HH-1)/2 - position;
            end
        end
    end
    