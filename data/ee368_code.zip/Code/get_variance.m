function variance = get_variance(tiles)
    lim = size(tiles);
    tile_avg = mean(mean(mean(tiles, 1), 2), 3);
    tile_avg = repmat(tile_avg, [lim(1), lim(2), lim(3), 1, 1]);
    variance = (tiles-tile_avg).^2;
    variance = reshape(mean(mean(mean(variance, 1), 2), 3), [lim(4), lim(5)]);
end