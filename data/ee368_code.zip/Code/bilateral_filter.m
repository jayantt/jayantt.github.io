function D = bilateral_filter(I, depth)
    
    disp('Applying Bilateral Filter')
    tic
    s = 21;
    L = (s-1)/2;
    Ig = sum(I,3);
    Ig = imresize(Ig,[size(depth,1),size(depth,2)]);
    D = depth;
    %Calculate image gradient direction
    dx = [1 0 -1; 1 0 -1; 1 0 -1];
    dy = dx';
    Ix = conv2(Ig,dx,'same');
    Iy = conv2(Ig,dy,'same');
    %Angle
    A = atan2(Ix,Iy)*180/pi;
    %Blurring kernel
    %K = ones(s);
    K = fspecial('gaussian',s,s/6);
    K(:,1:L) = 0;
    
    %Calculate 360 filters
    for i=1:360
        Ks{i} = imrotate(K,i-1,'crop');
    end
    
    for i=1+L:size(Ig,1)-L
        for j=1+L:size(Ig,2)-L
            kernel = Ks{mod(round(A(i,j)),360)+1};
            kernel = kernel/sum(kernel(:));
            D(i,j) = sum(sum(depth(i-L:i+L,j-L:j+L).*kernel));
        end
    end
    disp(['Finished in ' num2str(toc) ' seconds'])