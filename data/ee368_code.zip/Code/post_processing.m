function finalOut = post_processing(Du, invalid, saveFlag, outDir, debug)
    fprintf('\nPost-Processing...');

    se = strel('disk',3);
    tu = medfilt2(Du, [5,5]);
    im2u = imclose(tu,se);
    % dr = zeroFill(im2u);
    % im2 = imdilate(imdilate(imdilate(t, se), se), se);
    % im2 = imerode(imerode(imerode(im2, se), se), se);
    if debug == 1
        figure;
        imshow(im2u, [])
    end
    test = im2u;
    test(invalid == 1) = 0;
    filled = zeroFill(test, 10000);
    filled = medfilt2(filled, [10, 10]);
    finalFilled = zeroFill(filled, 50000);
    finalFilled = medfilt2(finalFilled, [10, 10]);
    str = zeros(10, 10);
    str(:, 5) = 1;
    str(5, :) = 1;
    closed = imclose(finalFilled, str);
    %closed(1440:end, :) = 0;
    finalOut = closed;
    if debug == 1
        figure;
        imshow(finalOut, []);
    end

    finalOut = wallFill(closed);
    if debug == 1
        figure;
        imshow(finalOut, []);
    end
    if saveFlag == 1
        save(strcat(outDir, 'disparity2.mat'), 'finalOut');
    end
end