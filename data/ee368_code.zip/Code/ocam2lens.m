% Splits an image into half images corresponding to each of the fish-eye
% lenses
cd F:/EE' 368'/Project/Images/Calibration;
for i=1:10
    im{i} = imread(sprintf('R001008%d.jpg', i-1));
    lim = size(im{i});
    out1{i} = im{i}(:, lim(2)/4+(1:lim(2)/2), :);
    out2{i} = cat(2, im{i}(:, lim(2)*3/4+(1:lim(2)/4), :), im{i}(:, 1:lim(2)/4, :));
    imwrite(out1{i}, sprintf('0_R001008%d.jpg', i-1), 'jpg');
    imwrite(out2{i}, sprintf('1_R001008%d.jpg', i-1), 'jpg');
end