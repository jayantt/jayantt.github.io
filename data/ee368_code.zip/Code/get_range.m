% Updates the search range, based on disparity map of the previous
% iteration, for finding feature matches
function r = get_range(map, matches)
    lim = size(matches);
    r = repmat(zeros(lim), [1, 1, 2]);
    for j=1:lim(2)
        temp = find(matches(:, j)==1);
        for i=1:lim(1)
            if i<=temp(1)
                r(i, j, 1) = 1;
            else
                r(i, j, 1) = map(temp(find(temp<i, 1, 'last')), j);
            end
            if i>=temp(end)
                r(i, j, 2) = lim(1);
            else
                r(i, j, 2) = map(temp(find(temp>i, 1)), j);
            end
        end
    end
end