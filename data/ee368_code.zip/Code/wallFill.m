function [ testIm ] = wallFill( im )
s = size(im);
wall = im;
widthBlock = 150;
step = round(s(2)/widthBlock);
fprintf('\nFilling in the Walls...');

for i = 1:step:s(2)
    endStep = i+step;
    if(endStep > s(2))
        endStep = s(2);
    end
    col = im(:,i:endStep);
    [bw, num] = bwlabel(col == 0);
    for k = 1:num
        reg = false(s(1), s(2));
        reg(:,i:endStep) = bw == k;
        str = strel('rectangle', [20, 10]);
        dilReg = imdilate(reg, str);
        edge = xor(dilReg, reg);
        mat = im(edge);
%         nonZeroInd = mat ~= 0;
        val = median(mat(mat ~= 0));
%         val = mean(testIm(nonZeroInd));
        wall(reg) = val;
    end
end

fprintf('\nBlurring Walls...');
zeros = im == 0;
f = fspecial('average', [100, 100]);
zblur = imfilter(wall, f);
zblur = imgaussfilt(zblur, 50);
testIm = im;
testIm(zeros) = round(zblur(zeros));

end

