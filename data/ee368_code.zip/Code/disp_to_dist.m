function [D] = disp_to_dist(d, delta)

    d;
    d(d < 0) = 0;
    [~, E1] = meshgrid(linspace(-180,180-1/size(d,2),size(d,2)),linspace(0,180,size(d,1)));
    E2 = E1 - d*180/size(d,1);
    E3 = E1-E2;
    D = ((sind(180-E1)+sind(E2))*delta./sind(E3))/2;