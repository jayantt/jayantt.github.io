function out = update_nbrs(clusters, loc, lim)
    out = clusters;
    temp = out(max(loc(1)-1, 1):min(loc(1)+1, lim(1)), max(loc(2)-1, 1):min(loc(2)+1, lim(2)));
    temp(temp==0) = -1;
    out(max(loc(1)-1, 1):min(loc(1)+1, lim(1)), max(loc(2)-1, 1):min(loc(2)+1, lim(2))) = temp;
    if loc(2)==1
        temp = out(max(loc(1)-1, 1):min(loc(1)+1, lim(1)), end);
        temp(temp==0) = -1;
        out(max(loc(1)-1, 1):min(loc(1)+1, lim(1)), end) = temp;
    end
    if loc(2)==lim(2)
        temp = out(max(loc(1)-1, 1):min(loc(1)+1, lim(1)), 1);
        temp(temp==0) = -1;
        out(max(loc(1)-1, 1):min(loc(1)+1, lim(1)), 1) = temp;
    end
end