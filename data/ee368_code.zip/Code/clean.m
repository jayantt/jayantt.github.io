function out = clean(clusters, loc, threshold, r, g, b)
    out = clusters;
    vec = [r(loc(1), loc(2)), g(loc(1), loc(2)), b(loc(1), loc(2))];
    nbr = find(clusters == -1);
    A = [r(nbr), g(nbr), b(nbr)];
    score = sum(A.*repmat(vec, [length(nbr), 1]), 2)./sqrt(sum(A.^2, 2)*sum(vec.^2));
    pos = score >= 1-10^(-threshold);
    neg = score < 1-10^(-threshold);
    out(nbr(pos)) = 1;
    out(nbr(neg)) = 0;
end