Supplementary Matrial: ICME 2016 / Paper 100

1. Introduction

This file contains two types of results. The first type of results are for head-motion parallax, where we demonstrate the ability of our representation to synthesize motion parallax. The second type of results showcase the ability of the proposed method to support refocusing of images by synthesizing light-fields from the proposed representation.

1. Directory Structure:

ZIP File

-> Head Motion Parallax Examples
->-> Disocclusions for Head Translation of 12 cm
->-> GIFs
->-> Video

-> Refocus Examples
->-> Refocus Videos
->-> Occlusions and Blur

2. Desciption of Individual Files

A. Head Motion Parallax Examples

This folder has 3 types of results. "Video" directory has a video of head-motion parallax produced on a natural scene using our representation. "GIFs" folder has a couple of GIFs for quick visualization. One of them is on a synthetic scene with the other one is on the natural scene. "Disocclusions" folder demonstrates the importance of using our representation with a large enough viewing radius. The folder has viewports synthesized for a head translation of 12 cm using representation radius varying from 15 cm to 0 cm (central projection). It can be seen that the quality of the synthesized viewports degrades, due to disocclusions, as the representation radius is decreased.

B. Refocus Results

Our representation can also be used to support dynamic refocusing of scenes in the context of VR. We can achieve this by synthesizing lightfield on-the-fly, for a given scene and then using the lightfield to perform refocusing. The folder named "Refocus Videos" contains 3 refocus videos for a synthetic scene - ground truth, produced using proposed representation, and produced using monoscopic central panorama and depth input. Notice that the refocus quality obtained using the proposed representation is visually indistinguishable from the ground truth. The results produced using central panorama and depth representation have disocclusion artifacts. They can be observed on the tiles on the ground, as dents in some of the colored frames, as well as inpainting artifacts in sky region around objects. The directory also contains 2 real world examples. Example 2 demosntrates the ability of the proposed method to work for different elevation and azimuth angles. The folder named "Occlusions and Blur" demonstrates that the defocusing works correctly at object boundaries. Foreground objects blur over the background objects, but the background objects don't blur on top of the foreground objects, as expected.