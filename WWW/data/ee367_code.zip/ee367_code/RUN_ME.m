% RUN_ME.m
% This script renders the views with motion parallax from the
% depth-augmented stereo panoramas (DASPs) stored in ./sample_dataset/eqr_frames 
% It renders views from both the synthetic and surround-360 DASPs. 

addpath('./matlab');

for use_facebook = [0 1] % 1 for facebook, 0 for synthetic data

    I = cell(2, 1);
    D = cell(2, 1);

    %% Config %%
    R = 0.218; % Rig radius
    N = 14; % No. of cameras on ring
    minDist = 1.5;
    in_f = inf;
    view_res = 1024;
    view_fov = 45;
    out_v = 0;
    out_f = inf;
    view_alt = 0;
    
    if use_facebook
        img = im2double(imread('./sample_dataset/eqr_frames/eqr_000000.jpg'));
        flw = im2double(imread('./sample_dataset/eqr_frames/eqrflow_000000.jpg'));
        in_v = 0.24/2;
        out_fname = 'fb_';
        view_az = deg2rad(-45);
    else
        in_v = 0.3/2;
        I{1} = im2double(imread('./sample_dataset/eqr_frames/omnistereo_ipd_0p15_L.jpg'));
        I{2} = im2double(imread('./sample_dataset/eqr_frames/omnistereo_ipd_0p15_R.jpg'));
        load './sample_dataset/eqr_frames/omnistereo_depth_ipd_0p15.mat';
        D{1} = sqrt(D{1}.^2-in_v^2); 
        D{2} = sqrt(D{2}.^2-in_v^2);
        out_fname = 'synth_';
        view_az = deg2rad(0);
    end

    if use_facebook

        %% Reading DASP %%
        [h, w, c] = size(img);
        h = h/2;
        for i=1:2
            I{i} = img((i-1)*h+(1:h), :, :);
            D{i} = flw((i-1)*h+(1:h), :, :);
            D{i}(D{i} < 0) = 0;
        end
        clear img flw;

        %% Preprocessing %%
        delta = pi/N;
        theta = repmat(pi/2 - ((1:h)' - 0.5) * pi/h, [1, w]);
        maxAngularDisp = 2 * atan(R * sin(delta) / (minDist - R * cos(delta)));
        for i=1:2
            D{i} = D{i} * maxAngularDisp;
            x = zeros(h, w);
            x(D{i}==0) = inf;
            x(D{i}~=0) = 2 * R * sin(delta) ./ D{i}(D{i}~=0) + R / cos(delta);
            z = tan(theta)/cos(delta) .* (x * cos(delta) - R);
            D{i} = sqrt(x.^2 + z.^2);
        end
    end

    %% Calling rendering code %%
    for i=[1 61]
        i
        out_v = (61-i) / 60 * in_v;
        if use_facebook
            [OL, OR, ODL, ODR] = renderView([in_v, in_f], [0, 0, 0], ...
            {out_v, out_f, view_alt, view_az, view_fov, view_res}, {I{1}, I{2}, D{1}, D{2}});
        else
            [OL, OR, ODL, ODR] = synth_renderView([in_v, in_f], [0, 0, 0], ...
            {out_v, out_f, view_alt, view_az, view_fov, view_res}, {I{1}, I{2}, D{1}, D{2}});
        end
        imwrite(OL, sprintf('./out/%s%03d.png', out_fname, i-1));
        imwrite(OR, sprintf('./out/%s%03d.png', out_fname, 121-i));
    end
end
