# Virtual Reality Motion Parallax with the Surround-360
# David Lindell & Jayant Thatte

note: Jayant was not in the class, but helped with the project.

The processing pipeline consists of two steps:
- Render a depth-augmented stereo panoramas (DASP) with the Facebook code
- Render viewports using the depth-augmented stereo panoramas

tl;dr: The depth-augmented stereo panoramas are already loaded into the
./sample_dataset/eqr_frames directory. Just run the RUN_ME.m matlab script
to generate motion parallax views from the panoramas. The RUN_ME.m script
will output images to the ./out folder. Generating the panoramas requires
compilation of c++ code that has a bunch of dependencies. It will compile, but
it's going to take more than 5 minutes to install all the dependencies and get it
working. 

---------------------------------------------
Running the Facebook Code to Render the DASP
---------------------------------------------
Although the Facebook code requires many dependencies to compile, you can just use the
pre-rendered DASPs to generate viewports using the Matlab code as explained in the 
next section. If you are actually interested in compiling the DASP-rendering 
code, read on.

Although the code has been heavily modified from it's original state on the 
Github repo, we include the license files and the original README.md file in the
meta_facebook folder.

The code has these dependencies
- CMake
- gflags
- glog
- OpenCV 3.0+
- Ceres

To run the code, you need to download and install these dependencies 
(more instructions for doing this in meta_facebook/README.md), 
and then you can run cmake and make to build the executable with the following commands.

```bash
$ cmake -DCMAKE_BUILD_TYPE=Release
$ make
```

Also, you will need to download the surround-360 data from the github repo at
http://surround360.hacktv.xyz/sample/sample_dataset.zip

Place the contents of the 'sample_dataset' folder into ./sample_dataset. 

Then, the DASP rendering script can be called with the following command
```bash
$ ./GenerateDASP.bash
```
which calls the TestRenderStereoPanorama binary (in the bin) folder. The Facebook
Surround-360 images used for processing are stored in the sample_dataset directory 
structure. The DASP output is stored in sample_dataset/eqr_frames

------------------------------
Rendering Views from the DASP
------------------------------

To render views from the Surround-360 and synthetic DASPs in the 
sample_dataset/eqr_frames directory, you can run the RUN_ME.m matlab script. 

This output images are written to the ./out folder




