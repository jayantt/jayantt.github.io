/**
* Copyright (c) 2016-present, Facebook, Inc.
* All rights reserved.
*
* This source code is licensed under the BSD-style license found in the
* LICENSE_render file in the root directory of this subproject. An additional grant
* of patent rights can be found in the PATENTS file in the same directory.
*/

#include "NovelView.h"

#include <string>
#include <vector>

#include "ColorAdjustmentSampleLogger.h"
#include "CvUtil.h"
#include "OpticalFlowFactory.h"
#include "OpticalFlowInterface.h"
#include "SystemUtil.h"

namespace surround360 {
namespace optical_flow {

using namespace std;
using namespace cv;
using namespace surround360::util;
using namespace surround360::color_adjust;

Mat NovelViewUtil::generateNovelViewSimpleCvRemap(
    const Mat& srcImage,
    const Mat& flow,
    const double t) {

  const int w = srcImage.cols;
  const int h = srcImage.rows;
  Mat warpMap = Mat(Size(w, h), CV_32FC2);
  for (int y = 0; y < h; ++y) {
    for (int x = 0; x < w; ++x) {
      Point2f flowDir = flow.at<Point2f>(y, x);
      warpMap.at<Point2f>(y, x) =
        Point2f(x + flowDir.x * t, y + flowDir.y * t);
    }
  }
  Mat novelView;
  remap(srcImage, novelView, warpMap, Mat(), CV_INTER_CUBIC);
  return novelView;
}

Mat NovelViewUtil::combineNovelViews(
    const Mat& imageL,
    const float blendL,
    const Mat& imageR,
    const float blendR,
    const Mat& flowLtoR,
    const Mat& flowRtoL) {

  Mat blendImage(imageL.size(), CV_8UC4);
  for (int y = 0; y < imageL.rows; ++y) {
    for (int x = 0; x < imageL.cols; ++x) {
      const Vec4b colorL = imageL.at<Vec4b>(y, x);
      const Vec4b colorR = imageR.at<Vec4b>(y, x);
      Vec4b colorMixed;
      if (colorL[3] == 0 && colorR[3] == 0 ) {
        colorMixed = Vec4b(0, 0, 0, 0);
      } else if (colorL[3] > 0 && colorR[3] == 0) {
        colorMixed = Vec4b(colorL[0], colorL[1], colorL[2], 255);
      } else if (colorL[3] == 0 && colorR[3] > 0) {
        colorMixed = Vec4b(colorR[0], colorR[1], colorR[2], 255);
      } else {
        const Point2f fLR = flowLtoR.at<Point2f>(y, x);
        const Point2f fRL = flowRtoL.at<Point2f>(y, x);
        const float flowMagLR = sqrtf(fLR.x * fLR.x + fLR.y * fLR.y) / float(imageL.cols);
        const float flowMagRL = sqrtf(fRL.x * fRL.x + fRL.y * fRL.y) / float(imageL.cols);
        const float colorDiff =
          (std::abs(colorL[0] - colorR[0]) +
           std::abs(colorL[1] - colorR[1]) +
           std::abs(colorL[2] - colorR[2])) / 255.0f;
        static const float kColorDiffCoef = 10.0f;
        static const float kSoftmaxSharpness = 10.0f;
        static const float kFlowMagCoef = 100.0f; // determines how much we prefer larger flows
        const float deghostCoef = tanhf(colorDiff * kColorDiffCoef);
        const float alphaL = colorL[3] / 255.0f;
        const float alphaR = colorR[3] / 255.0f;
        const double expL =
          exp(kSoftmaxSharpness * blendL * alphaL * (1.0 + kFlowMagCoef * flowMagRL));
        const double expR =
          exp(kSoftmaxSharpness * blendR * alphaR * (1.0 + kFlowMagCoef * flowMagLR));
        const double sumExp = expL + expR + 0.00001;
        const float softmaxL = float(expL / sumExp);
        const float softmaxR = float(expR / sumExp);
        colorMixed = Vec4b(
          float(colorL[0]) * lerp(blendL, softmaxL, deghostCoef) + float(colorR[0]) * lerp(blendR, softmaxR, deghostCoef),
          float(colorL[1]) * lerp(blendL, softmaxL, deghostCoef) + float(colorR[1]) * lerp(blendR, softmaxR, deghostCoef),
          float(colorL[2]) * lerp(blendL, softmaxL, deghostCoef) + float(colorR[2]) * lerp(blendR, softmaxR, deghostCoef),
          255);
      }
      blendImage.at<Vec4b>(y, x) = colorMixed;
    }
  }
  return blendImage;
}

template <typename T>
Mat NovelViewUtil::combineLazyViews(
    const Mat& imageL,
    const Mat& imageR,
    const Mat& flowMagL,
    const Mat& flowMagR,
    const int leftImageIdx,
    const int rightImageIdx) {

	Mat blendImage;
	float scaleFactor;
	if (std::is_same<T, Vec4b>::value) {
	  blendImage = Mat(imageL.size(), CV_8UC4);
	  scaleFactor = 255.0;
	}
	else if (std::is_same<T, Vec4f>::value) {
	  blendImage = Mat(imageL.size(), CV_32FC4);
	  scaleFactor = 1.0;
	}

  ColorAdjustmentSampleLogger& colorSampleLogger =
    ColorAdjustmentSampleLogger::instance();

  for (int y = 0; y < imageL.rows; ++y) {
    for (int x = 0; x < imageL.cols; ++x) {
      const T colorL = imageL.at<T>(y, x);
      const T colorR = imageR.at<T>(y, x);

      const unsigned char outAlpha =
        max(colorL[3], colorR[3]) / scaleFactor > 0.1 ? scaleFactor : 0;

      T colorMixed;
      if (colorL[3] == 0 && colorR[3] == 0) {
        colorMixed = T(0, 0, 0, outAlpha);
      } else if (colorL[3] == 0) {
        colorMixed = T(colorR[0], colorR[1], colorR[2], outAlpha);
      } else if (colorR[3] == 0) {
        colorMixed = T(colorL[0], colorL[1], colorL[2], outAlpha);
      } else {

        // log the colors that are being blended so we can adjust the images
        // color/brightness (requires a second pass/re-render).

      	if (leftImageIdx != -1 && rightImageIdx != -1) {
      		colorSampleLogger.addSample(
      				leftImageIdx,
							rightImageIdx,
							colorL,
							colorR);
      	}

        const float magL = flowMagL.at<float>(y,x) / float(imageL.cols);
        const float magR = flowMagR.at<float>(y,x) / float(imageL.cols);
        float blendL = float(colorL[3]);
        float blendR = float(colorR[3]);
        float norm = blendL + blendR;
        blendL /= norm;
        blendR /= norm;
        const float colorDiff =
          (std::abs(colorL[0] - colorR[0]) +
           std::abs(colorL[1] - colorR[1]) +
           std::abs(colorL[2] - colorR[2])) / scaleFactor;
        static const float kColorDiffCoef = 10.0f;
        static const float kSoftmaxSharpness = 10.0f;
        static const float kFlowMagCoef = 20.0f; // NOTE: this is scaled differently than the test version due to normalizing magL & magR by imageL.cols
        const float deghostCoef = tanhf(colorDiff * kColorDiffCoef);
        const double expL = exp(kSoftmaxSharpness * blendL * (1.0 + kFlowMagCoef * magL));
        const double expR = exp(kSoftmaxSharpness * blendR * (1.0 + kFlowMagCoef * magR));
        const double sumExp = expL + expR + 0.00001;
        const float softmaxL = float(expL / sumExp);
        const float softmaxR = float(expR / sumExp);
        colorMixed = T(
          float(colorL[0]) * lerp(blendL, softmaxL, deghostCoef) + float(colorR[0]) * lerp(blendR, softmaxR, deghostCoef),
          float(colorL[1]) * lerp(blendL, softmaxL, deghostCoef) + float(colorR[1]) * lerp(blendR, softmaxR, deghostCoef),
          float(colorL[2]) * lerp(blendL, softmaxL, deghostCoef) + float(colorR[2]) * lerp(blendR, softmaxR, deghostCoef),
          scaleFactor);
      }
      blendImage.at<T>(y, x) = colorMixed;
    }
  }
  return blendImage;
}

void NovelViewGeneratorLazyFlow::asignFlow(
  Mat inputFlow,
  string direction) {

  if (direction == "LtoR")
	flowLtoR = inputFlow;
  if (direction == "RtoL")
	flowRtoL = inputFlow;
}

void NovelViewGeneratorLazyFlow::generateNovelView(
    const double shiftFromL,
    Mat& outNovelViewMerged,
    Mat& outNovelViewFromL,
    Mat& outNovelViewFromR) {

  outNovelViewFromL = NovelViewUtil::generateNovelViewSimpleCvRemap(
    imageL, flowRtoL, shiftFromL);

  outNovelViewFromR = NovelViewUtil::generateNovelViewSimpleCvRemap(
    imageR, flowLtoR, 1.0 - shiftFromL);

  outNovelViewMerged = NovelViewUtil::combineNovelViews(
    outNovelViewFromL, 1.0 - shiftFromL,
    outNovelViewFromR, shiftFromL,
    flowLtoR, flowRtoL);
}

static int first = 0;

pair<Mat, Mat> NovelViewGeneratorLazyFlow::renderLazyNovelView(
    const int width,
    const int height,
    const vector<vector<Point3f>>& novelViewWarpBuffer,
    const Mat& srcImage,
    const Mat& opticalFlow,
    const bool invertT,
	const float fovVerticalRadians,
	Mat extraOpticalFlow,
	Mat extraImage) {

  // parameters to estimate pixels in extra view to be used
	bool useExtraViews = 0;
	const int viewOverlap = 8;									// number of pixels to overlap between image and extrapolated image
	float startX = novelViewWarpBuffer[0][floor(srcImage.rows/2)].x; // x position at which chunks start
	Mat rowStartX = Mat(novelViewWarpBuffer[0]);
	Mat warpBufferXYZ[3];
	split(rowStartX,warpBufferXYZ);
	rowStartX = warpBufferXYZ[0];
	float limitX;															  // last chunk index within bounds
	Mat offset;																	// pixel offset between first chunk of extra image and overlapIdx
  Mat overlapIdx;															// index of last in-bounds pixel

	float endX = startX + width;
	if (startX > 0) { // if using left image
		limitX = srcImage.cols - 1;
		overlapIdx = limitX-rowStartX - viewOverlap;
		overlapIdx.convertTo(overlapIdx, CV_32S);
	 	offset = width - overlapIdx - 1;
	}
	else {
		limitX = 0;
		offset = (-width) * Mat::ones(rowStartX.size(), CV_32S);
		overlapIdx = limitX - rowStartX + viewOverlap;
		overlapIdx.convertTo(overlapIdx, CV_32S);
	}

	if (startX < 0 || endX > limitX) {
		useExtraViews = 1;
	}

	// grab chunks from overlap image
  Mat warpOpticalFlow = Mat(Size(width, height), CV_32FC2);
  Mat extraWarpOpticalFlow = Mat(Size(width,height), CV_32FC2);
  for (int y = 0; y < height; ++y) {
    for (int x = 0; x < width; ++x) {
      const Point3f lazyWarp = novelViewWarpBuffer[x][y];
      warpOpticalFlow.at<Point2f>(y, x) = Point2f(lazyWarp.x, lazyWarp.y);
      extraWarpOpticalFlow.at<Point2f>(y,x) = Point2f(lazyWarp.x - offset.at<int>(y,0), lazyWarp.y);
    }
  }

  Mat remappedFlow;
  remap(opticalFlow, remappedFlow, warpOpticalFlow, Mat(), CV_INTER_CUBIC);
  Mat extraRemappedFlow;
  remap(extraOpticalFlow, extraRemappedFlow, extraWarpOpticalFlow, Mat(), CV_INTER_CUBIC);

  // Optical flow from original pixels to novel view pixels
  Mat warpComposition = Mat(Size(width, height), CV_32FC2);
  Mat extraWarpComposition = Mat(Size(width, height), CV_32FC2);
  int numNovelViews = 450;

  for (int y = 0; y < height; ++y) {
  	float costheta = cos(abs(-fovVerticalRadians/2 + fovVerticalRadians*(y+0.5)/height));
    for (int x = 0; x < width; ++x) {
      const Point3f lazyWarp = novelViewWarpBuffer[x][y];

      Point2f flowDir = remappedFlow.at<Point2f>(y, x);
      Point2f extraFlowDir = extraRemappedFlow.at<Point2f>(y, x);
      // the 3rd coordinate (z) of novelViewWarpBuffer is shift/time value
      const float t = invertT ? (1.0f - lazyWarp.z) : lazyWarp.z;
      warpComposition.at<Point2f>(y, x) =
        Point2f(lazyWarp.x + flowDir.x * t * costheta, lazyWarp.y + flowDir.y * t * costheta);

      float extraT;
      if (startX > 0)
      	 extraT = (-float(offset.at<int>(y,0)) + x) / numNovelViews;
      else
      	 extraT = -float(x) / numNovelViews;

      extraWarpComposition.at<Point2f>(y, x) =
        Point2f(lazyWarp.x - offset.at<int>(y,0) + extraFlowDir.x * extraT * costheta, lazyWarp.y + extraFlowDir.y * extraT * costheta);
    }
  }

  // this remap generates the novel view from the optical flow
  Mat novelView;
  remap(srcImage, novelView, warpComposition, Mat(), CV_INTER_CUBIC);
  remap(opticalFlow, remappedFlow, warpComposition, Mat(), CV_INTER_CUBIC);

  if (useExtraViews) {
		Mat extraNovelView;
		remap(extraImage, extraNovelView, extraWarpComposition, Mat(), CV_INTER_CUBIC);
		remap(extraOpticalFlow, extraRemappedFlow, extraWarpComposition, Mat(), CV_INTER_CUBIC);

		Mat tmp;
		Mat img;
		Mat combined;
		Mat combinedFlow;

		if (startX > 0) {
			for (int i = 0; i < srcImage.rows; ++i) {
				img = novelView(Rect(0,i,overlapIdx.at<int>(i,0)+1,1));
				extraImage = extraNovelView(Rect(0,i,width-(overlapIdx.at<int>(i,0)+1),1));
				hconcat(img, extraImage, tmp);
				combined.push_back(tmp.clone());
                
				img = remappedFlow(Rect(0,i,overlapIdx.at<int>(i,0)+1,1));
				extraImage = extraRemappedFlow(Rect(0,i,width-(overlapIdx.at<int>(i,0)+1),1));
				hconcat(img, extraImage, tmp);
				combinedFlow.push_back(tmp.clone());
			}

//			tmp = novelView(Rect(0,0,overlapIdx.at<int>(y,x)+1,novelView.rows)).clone();
//			extraImage = extraNovelView(Rect(0,0,width-(overlapIdx.at<int>(y,x)+1),novelView.rows));
//			hconcat(tmp, extraImage, combined);

		}
		else  {
			for (int i = 0; i < srcImage.rows; ++i) {
				img = novelView(Rect(overlapIdx.at<int>(i,0)+1,i,width - (overlapIdx.at<int>(i,0)+1),1));
				extraImage = extraNovelView(Rect(0,i,overlapIdx.at<int>(i,0)+1,1));
				hconcat(extraImage, img, tmp);
				combined.push_back(tmp);

				img = remappedFlow(Rect(overlapIdx.at<int>(i,0)+1,i,width - (overlapIdx.at<int>(i,0)+1),1));
				extraImage = extraRemappedFlow(Rect(0,i,overlapIdx.at<int>(i,0)+1,1));
				hconcat(extraImage, img, tmp);
				combinedFlow.push_back(tmp);
			}
//			tmp = novelView(Rect(overlapIdx.at<int>(i,0)+1,0,width - (overlapIdx.at<int>(i,0)+1),novelView.rows));
//			extraImage = extraNovelView(Rect(0,0,overlapIdx.at<int>(i,0)+1,novelView.rows));
//			hconcat(extraImage, tmp, combined);
		}
		novelView = combined;
		remappedFlow = combinedFlow;
  }
	Mat novelViewFlowMag(novelView.size(), CV_32F);
	// so far we haven't quite set things up to exactly match the original
	// O(n^3) algorithm. we need to blend the two novel views based on the
	// time shift value. we will pack that into the alpha channel here,
	// then use it to blend the two later.
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; ++x) {
			Point3f lazyWarp;
			Point2f flowDir;
			float t;

  		if (((x > overlapIdx.at<int>(y,0) && startX > 0) || (x <= overlapIdx.at<int>(y,0) && startX < 0)) && useExtraViews) {
        lazyWarp = novelViewWarpBuffer[x][y];
        t = 0.5;
    	}
    	else { // iterating over normal image pixels
        lazyWarp = novelViewWarpBuffer[x][y];
        //flowDir = remappedFlow.at<Point2f>(y, x);
				if (startX > 0)
					t = lazyWarp.z * float(width) / overlapIdx.at<int>(y,0);
				else
					t = 1 - float(width) / (width - overlapIdx.at<int>(y,0)) * (1 - lazyWarp.z);
				if (t < 0)
					t = 0;
				if (t > 1)
					t = 1;
				t = invertT ? (1.0f - t) : t;
    	}
      flowDir = remappedFlow.at<Point2f>(y, x);
      novelView.at<Vec4b>(y, x)[3] =
        int((1.0f - t) * novelView.at<Vec4b>(y, x)[3]);
      novelViewFlowMag.at<float>(y, x) =
        sqrtf(flowDir.x * flowDir.x + flowDir.y * flowDir.y);
    }
  }

  return make_pair(novelView, novelViewFlowMag);
}

tuple<Mat, Mat, Mat, Mat> NovelViewGeneratorLazyFlow::combineLazyNovelViews(
    const LazyNovelViewBuffer& lazyBuffer,
    const int leftImageIdx,
    const int rightImageIdx,
	const float fovVerticalRadians,
	const vector<NovelViewGenerator*> *extraViewGenerators) {

  // two images for the left eye (to be combined)
  pair<Mat, Mat> leftEyeFromLeft = renderLazyNovelView(
    lazyBuffer.width, lazyBuffer.height,
    lazyBuffer.warpL,
    imageL,
    flowRtoL,
    false,
	fovVerticalRadians,
	extraViewGenerators->at(1)->getFlowRtoL(),
	extraViewGenerators->at(1)->getImageL());
  pair<Mat, Mat> leftEyeFromRight = renderLazyNovelView(
    lazyBuffer.width, lazyBuffer.height,
    lazyBuffer.warpL,
    imageR,
    flowLtoR,
    true,
	fovVerticalRadians,
	extraViewGenerators->at(1)->getFlowRtoL(),
	extraViewGenerators->at(1)->getImageL());

  // two images for the right eye (to be combined)
  pair<Mat, Mat> rightEyeFromLeft = renderLazyNovelView(
    lazyBuffer.width, lazyBuffer.height,
    lazyBuffer.warpR,
    imageL,
    flowRtoL,
    false,
	fovVerticalRadians,
	extraViewGenerators->at(0)->getFlowLtoR(),
	extraViewGenerators->at(0)->getImageR());
  pair<Mat, Mat> rightEyeFromRight = renderLazyNovelView(
    lazyBuffer.width, lazyBuffer.height,
    lazyBuffer.warpR,
    imageR,
    flowLtoR,
    true,
	fovVerticalRadians,
	extraViewGenerators->at(0)->getFlowLtoR(),
	extraViewGenerators->at(0)->getImageR());

  Mat leftEyeCombined = NovelViewUtil::combineLazyViews<Vec4b>(
    leftEyeFromLeft.first,
    leftEyeFromRight.first,
    leftEyeFromLeft.second,
    leftEyeFromRight.second,
    leftImageIdx,
    rightImageIdx);
  Mat rightEyeCombined = NovelViewUtil::combineLazyViews<Vec4b>(
    rightEyeFromLeft.first,
    rightEyeFromRight.first,
    rightEyeFromLeft.second,
    rightEyeFromRight.second,
    leftImageIdx,
    rightImageIdx);

  // // Pass flow through the same warping // //
  Mat leftEyeFromLeftFlow;
  Mat leftEyeFromRightFlow;
  Mat rightEyeFromLeftFlow;
  Mat rightEyeFromRightFlow;
  cvtColor(leftEyeFromLeft.second,leftEyeFromLeftFlow,COLOR_GRAY2BGRA);
  cvtColor(leftEyeFromRight.second,leftEyeFromRightFlow,COLOR_GRAY2BGRA);
  cvtColor(rightEyeFromLeft.second,rightEyeFromLeftFlow,COLOR_GRAY2BGRA);
  cvtColor(rightEyeFromRight.second,rightEyeFromRightFlow,COLOR_GRAY2BGRA);
	for (int y = 0; y < leftEyeFromLeftFlow.rows; ++y) {
		for (int x = 0; x < leftEyeFromLeftFlow.cols; ++x) {
			leftEyeFromLeftFlow.at<Vec4f>(y,x)[3] = float(leftEyeFromLeft.first.at<Vec4b>(y,x)[3])/255;
			leftEyeFromRightFlow.at<Vec4f>(y,x)[3] = float(leftEyeFromRight.first.at<Vec4b>(y,x)[3])/255;
			rightEyeFromLeftFlow.at<Vec4f>(y,x)[3] = float(rightEyeFromLeft.first.at<Vec4b>(y,x)[3])/255;
			rightEyeFromRightFlow.at<Vec4f>(y,x)[3] = float(rightEyeFromRight.first.at<Vec4b>(y,x)[3])/255;
		}
	}

  // Pass through the same combining function //
  Mat leftEyeCombinedFlow = NovelViewUtil::combineLazyViews<Vec4f>(
    leftEyeFromLeftFlow,
    leftEyeFromRightFlow,
    leftEyeFromLeft.second,
    leftEyeFromRight.second,
    leftImageIdx,
    rightImageIdx);
  Mat rightEyeCombinedFlow = NovelViewUtil::combineLazyViews<Vec4f>(
    rightEyeFromLeftFlow,
    rightEyeFromRightFlow,
    rightEyeFromLeft.second,
    rightEyeFromRight.second,
    leftImageIdx,
    rightImageIdx);
  
  // Extract a single channel from each combined flow //
  vector <Mat> leftEyeCombinedFlowV;
  vector <Mat> rightEyeCombinedFlowV;

  split(leftEyeCombinedFlow, leftEyeCombinedFlowV);
  split(rightEyeCombinedFlow, rightEyeCombinedFlowV);
  
  return make_tuple(leftEyeCombined, rightEyeCombined, leftEyeCombinedFlowV[0], rightEyeCombinedFlowV[0]);
}

void NovelViewGeneratorAsymmetricFlow::prepare(
    const Mat& colorImageL,
    const Mat& colorImageR,
    const Mat& prevFlowLtoR,
    const Mat& prevFlowRtoL,
    const Mat& prevColorImageL,
    const Mat& prevColorImageR) {

  imageL = colorImageL.clone();
  imageR = colorImageR.clone();

  OpticalFlowInterface* flowAlg = makeOpticalFlowByName(flowAlgName);
  flowAlg->computeOpticalFlow(
    imageL,
    imageR,
    prevFlowLtoR,
    prevColorImageL,
    prevColorImageR,
    flowLtoR,
    OpticalFlowInterface::DirectionHint::LEFT);
  flowAlg->computeOpticalFlow(
    imageR,
    imageL,
    prevFlowRtoL,
    prevColorImageR,
    prevColorImageL,
    flowRtoL,
    OpticalFlowInterface::DirectionHint::RIGHT);
  delete flowAlg;
}

} // namespace reprojection
} // namespace surround360
