function [OL, OR, ODL, ODR] = renderView(input_params, translation, output_params, inputs)
in_v = input_params(1);
in_f = input_params(2);
T = translation;
[out_v, out_f, view_alt, view_az, view_fov, view_res] = deal(output_params{:});
[IL, IR, DL, DR] = deal(inputs{:});
out_type = 'view';
% Source to Target Depth Warp
    if in_v && out_v
        fprintf('\nInput: stereo\tOutput: stereo');
        fprintf('\nDepth warps: 4\tImage warps: 4\tBlending: 2\tInpainting: 2\n\n');
        ODL1 = s2t_depth_warp(IL, DL, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'left', 'left');
        ODR1 = s2t_depth_warp(IL, DL, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'left', 'right');
        ODL2 = s2t_depth_warp(IR, DR, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'right', 'left');
        ODR2 = s2t_depth_warp(IR, DR, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'right', 'right');
    elseif in_v && (~out_v)
        fprintf('\nInput: stereo\tOutput: mono');
        fprintf('\nDepth warps: 2\tImage warps: 2\tBlending: 1\tInpainting: 1\n\n');
        ODM1 = s2t_depth_warp(IL, DL, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'left', 'mono');
        ODM2 = s2t_depth_warp(IR, DR, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'right', 'mono');
    elseif (~in_v) && out_v
        fprintf('\nInput: mono\tOutput: stereo');
        fprintf('\nDepth warps: 2\tImage warps: 2\tBlending: 0\tInpainting: 2\n\n');
        ODL = s2t_depth_warp(I, D, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'mono', 'left');
        ODR = s2t_depth_warp(I, D, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'mono', 'right');
    else
        fprintf('\nInput: mono\tOutput: mono');
        fprintf('\nDepth warps: 1\tImage warps: 1\tBlending: 0\tInpainting: 1\n\n');
        ODL = s2t_depth_warp(I, D, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'mono', 'mono');
        ODR = ODL;
    end
    % Target to Source Image Warp
    if in_v && out_v
        OL1 = t2s_image_warp(IL, ODL1, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'left', 'left');
        OR1 = t2s_image_warp(IL, ODR1, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'left', 'right');
        OL2 = t2s_image_warp(IR, ODL2, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'right', 'left');
        OR2 = t2s_image_warp(IR, ODR2, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'right', 'right');
        % Blending output images
        [OL, ODL] = blend(OL1, OL2, ODL1, ODL2, 'mono');
        [OR, ODR] = blend(OR1, OR2, ODR1, ODR2, 'mono');
    elseif in_v && (~out_v)
        OM1 = t2s_image_warp(IL, ODM1, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'left', 'mono');
        OM2 = t2s_image_warp(IR, ODM2, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, 'right', 'mono');
        % Blending output images
        [OM, ODM] = blend(OM1, OM2, ODM1, ODM2, 'mono');
        OL = OM; OR = OM; ODL = ODM; ODR = ODM;
    end
    fprintf('All Done.\n\n');
return

function OD = s2t_depth_warp(I, D, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, source_leftright, target_leftright)
    % Initializing
    tic;
    fprintf('Warping depth...\t\t\t');
    [H, W, ~] = size(I);
    % Image coordinates from Pixel coordinates
    [az, alt] = pixel2image('pano', H, W);
    % World coordinates from image coordinates
    [xtp, ytp, ztp] = image2world('pano', alt, az, D, T, in_v, in_f, nan, nan, source_leftright);
    % New image coordinates from world coordinates
    [coord1, coord2, Dout] = world2image(out_type, xtp, ytp, ztp, out_v, out_f, view_alt, view_az, target_leftright);
    % Pixel coordinates from image coordinates
    [x, y] = image2pixel(out_type, coord1, coord2, H, W, view_fov, view_res, 0);
    % Warping depths
    OD = warp_depth(out_type, x, y, Dout, view_res);
    toc;
return

function [coord2, coord1] = pixel2image(out_type, H, W, view_fov, view_res)
    if strcmp(out_type, 'pano')
        % 1:W -> pi:-pi and 1:H -> pi/2:-pi/2, half pixel convention
        [coord2, coord1] = meshgrid(linspace(pi-pi/W, -pi+pi/W, W), linspace(pi/2-pi/2/H, -pi/2+pi/2/H, H));
    else
        [coord1, coord2] = meshgrid(1:view_res, 1:view_res);
        coord2 = view_res+1-coord2;
        lim = tan(view_fov/2);
        coord1 = (coord1-0.5)/view_res*(2*lim)-lim;
        coord2 = (coord2-0.5)/view_res*(2*lim)-lim;
    end
return 

function [xp, yp, zp] = image2world(out_type, coord1, coord2, D, T, v, f, view_alt, view_az, leftright)
if strcmp(out_type, 'pano')
    alt = coord1; az = coord2;
    if ~isinf(f)
        if strcmp(leftright, 'left')
            % Left stereo view
            az0 = atan(abs(sqrt(f^2 - v^2)*cos(alt)/v));
            xp = v*cos(az+az0)+D.*cos(alt).*sin(az+az0)-T(1);
            yp = v*sin(az+az0)-D.*cos(alt).*cos(az+az0)-T(2);
            zp = D.*sin(alt)-T(3);
        elseif strcmp(leftright, 'right')
            % Right stereo view
            az0 = atan(abs(sqrt(f^2 - v^2)*cos(alt)/v));
            xp = v*cos(az-az0)-D.*cos(alt).*sin(az-az0)-T(1);
            yp = v*sin(az-az0)+D.*cos(alt).*cos(az-az0)-T(2);
            zp = D.*sin(alt)-T(3);
        else
            % Mono view
            [xp, yp, zp] = sph2cart(az, alt, D);
            xp = xp-T(1); yp = yp-T(2); zp = zp-T(3);
        end
    else
        if strcmp(leftright, 'left')
            aza = az+pi/2;
            xa = v*cos(alt).*cos(aza); ya = v*cos(alt).*sin(aza);
            xp = xa + D.*cos(alt).*cos(az)-T(1);
            yp = ya + D.*cos(alt).*sin(az)-T(2);
            zp = D.*sin(alt)-T(3);
        elseif strcmp(leftright, 'right')
            aza = az-pi/2;
            xa = v*cos(alt).*cos(aza); ya = v*cos(alt).*sin(aza);
            xp = xa + D.*cos(alt).*cos(az)-T(1);
            yp = ya + D.*cos(alt).*sin(az)-T(2);
            zp = D.*sin(alt)-T(3);
        else
            [xp, yp, zp] = sph2cart(az, alt, D);
            xp = xp-T(1); yp = yp-T(2); zp = zp-T(3);
        end
    end
else
    X = coord1; Y = coord2; % Viewport coordinates in distance units (graph axis convention)
    [H, W] = size(X);
    N = [cos(view_alt)*cos(view_az), cos(view_alt)*sin(view_az), sin(view_alt)]; % Outward pointing normal vector to the viewport plane
    V1 = [N(2), -N(1), 0]; V1 = V1/norm(V1); % X axis of viewport coordinates in terms of world coordinates
    V2 = cross(V1, N); % Y axis of viewport coordinates in terms of world coordinates
    A = [V1; V2; -N]; % Projection matrix
    XY = [reshape(X, [], 1), reshape(Y, [], 1), -ones(H*W, 1)];
    xyzq = XY*A;
    % Q is location of image point on viewport; xq, yq, zq are its world coordinates
    xq = reshape(xyzq(:, 1), H, W); yq = reshape(xyzq(:, 2), H, W); zq = reshape(xyzq(:, 3), H, W);
    factor = D./sqrt(xq.^2+yq.^2+zq.^2);
    % P is the actual scene point; xp, yp, zp are its world coordinates
    xp = factor.*xq; yp = factor.*yq; zp = factor.*zq;
    % If input viewport is stereo, shift to head position from eye position
    if strcmp(leftright, 'left')
        xp = xp-V1(1)*v; yp = yp-V1(2)*v;
    elseif strcmp(leftright, 'right')
        xp = xp+V1(1)*v; yp = yp+V1(2)*v;
    end
    xp = xp-T(1); yp = yp-T(2); zp = zp-T(3);
end
return

function [coord1, coord2, Dout] = world2image(out_type, xp, yp, zp, v, f, view_alt, view_az, leftright)
    if strcmp(out_type, 'pano')
        if ~isinf(f)
            if strcmp(leftright, 'mono')
                [azb, altb, Dout] = cart2sph(xp, yp, zp);
            else
                Dout = sqrt(max(0, xp.^2+yp.^2-v^2)+zp.^2);
                altb = asin(zp./Dout);
                altb(Dout == 0) = 0;
                d = Dout.*cos(altb);
                az0 = atan(abs(sqrt(f^2 - v^2)*cos(altb)/v));
                if strcmp(leftright, 'left')
                    % Left stereo view
                    az = atan2(d.*xp+v*yp, v*xp-d.*yp);
                    azb = az - az0;
                elseif strcmp(leftright, 'right')
                    % Right stereo view
                    az = atan2(-d.*xp+v*yp, v*xp+d.*yp);
                    azb = az + az0;
                end
            end
            coord1 = altb; coord2 = azb;
        else
            if strcmp(leftright, 'mono')
                [azb, altb, Dout] = cart2sph(xp, yp, zp);
            else
                [azp, altp, Dp] = cart2sph(xp, yp, zp);
                if strcmp(leftright, 'left')
                    aza = azp+acos(v./Dp);
                    aza(Dp<v) = azp(Dp<v)+pi/2;
                elseif strcmp(leftright, 'right')
                    aza = azp-acos(v./Dp);
                    aza(Dp<v) = azp(Dp<v)-pi/2;
                end
                xa = v*cos(altp).*cos(aza); ya = v*cos(altp).*sin(aza);
                [azb, altb, Dout] = cart2sph(xp-xa, yp-ya, zp);
                Dout(Dp<v) = 0;
            end
            coord1 = altb; coord2 = azb;
        end
    else
        [H, W] = size(xp);
        N = [cos(view_alt)*cos(view_az), cos(view_alt)*sin(view_az), sin(view_alt)];
        V1 = [N(2), -N(1), 0]; V1 = V1/norm(V1);
        V2 = cross(V1, N);
        A = [V1; V2; -N]^-1;
        if strcmp(leftright, 'left')
            xp = xp+V1(1)*v; yp = yp+V1(2)*v;
        elseif strcmp(leftright, 'right')
            xp = xp-V1(1)*v; yp = yp-V1(2)*v;
        end
        factor = xp*N(1)+yp*N(2)+zp*N(3);
        xq = reshape(xp./factor, [], 1); yq = reshape(yp./factor, [], 1); zq = reshape(zp./factor, [], 1);
        XY = [xq, yq, zq]*A(:, 1:2);
        X = reshape(XY(:, 1), H, W);
        Y = reshape(XY(:, 2), H, W);
        Dout = sqrt(xp.^2+yp.^2+zp.^2);
        X(factor<0)=nan; Y(factor<0)=nan; Dout(factor<0)=nan;
        coord1 = X; coord2 = Y;
    end
return

function [x, y] = image2pixel(out_type, coord1, coord2, H, W, view_fov, view_res, rnd)
    if strcmp(out_type, 'pano')
        alt = coord1; az = coord2;
        if rnd
            x = mod(round((-az+pi)/(2*pi)*W-0.5), W)+1;
            y = mod(round((-alt+pi/2)/pi*H-0.5), H)+1;
        else
            x = mod((-az+pi)/(2*pi)*W-0.5, W)+1;
            y = mod((-alt+pi/2)/pi*H-0.5, H)+1;
        end
    else
        X = coord1; Y = coord2;
        lim = tan(view_fov/2);
        % -lim:lim -> 1:res
        x = (X+lim)*view_res/(2*lim)+0.5;
        y = (Y+lim)*view_res/(2*lim)+0.5;
        if rnd
            x = round(x);
            y = round(y);
        end
        y = view_res+1-y;
    end
return

function Dout = warp_depth(out_type, x, y, D, view_res)
    % This function does depth warping
    if strcmp(out_type, 'pano')
        [H, W] = size(D);
        Dout = zeros(H, W);
    else
        valid = (x>0.5 & x<view_res+0.5 & y>0.5 & y<view_res+0.5);
        x = x(valid); y = y(valid); D = D(valid);
        x = round(x); y = round(y);
        Dout = zeros(view_res);
    end
    X = reshape(x, [], 1); Y = reshape(y, [], 1); D = reshape(D, [], 1);
    XYD = [X, Y, D];
    XYD = sortrows(XYD, -3);
    X = XYD(:, 1); Y = XYD(:, 2); D = XYD(:, 3);
    for i=1:length(D)
        Dout(Y(i), X(i)) = D(i);
    end
    if strcmp(out_type, 'view')
        temp1 = imclose(Dout~=0, ones(2));
        temp2 = imclose(Dout~=0, ones(3));
        temp3 = imclose(Dout~=0, ones(4));
        temp2(3*view_res/8+(1:view_res/4), 3*view_res/8+(1:view_res/4)) = temp1(3*view_res/8+(1:view_res/4), 3*view_res/8+(1:view_res/4));
        temp3(view_res/8+(1:6*view_res/8), view_res/8+(1:6*view_res/8)) = temp2(view_res/8+(1:6*view_res/8), view_res/8+(1:6*view_res/8));
        [u, v] = find(Dout~=0);
        F = scatteredInterpolant(u, v, Dout(Dout~=0));
        [U, V] = meshgrid(1:view_res, 1:view_res);
        FVU = F(V, U);
        FVU(isnan(FVU)) = 0;
        Dout = imopen(FVU, ones(5));
        Dout(temp3==0) = 0;
    else
        temp = medfilt2(Dout, [3, 1], 'symmetric');
        temp = medfilt2(temp, [1, 3], 'symmetric');
        idx = Dout==0; Dout(idx) = temp(idx);
        Dout = medfilt2(Dout, [3, 1], 'symmetric');
        Dout = medfilt2(Dout, [1, 3], 'symmetric');
    end
return

function Iout = t2s_image_warp(I, D, in_v, in_f, T, out_type, out_v, out_f, view_alt, view_az, view_fov, view_res, source_leftright, target_leftright)
    % Initializing
    tic;
    fprintf('Warping image...\t\t\t');
    [H, W, ~] = size(I);
    [coord2, coord1] = pixel2image(out_type, H, W, view_fov, view_res);
    % World coordinates from target image coordinates
    [xp, yp, zp] = image2world(out_type, coord1, coord2, D, -T, out_v, out_f, view_alt, view_az, target_leftright);
    % Source image coordinates from world coordinates
    [altb, azb, ~] = world2image('pano', xp, yp, zp, in_v, in_f, nan, nan, source_leftright);
    % Pixel coordinates from polar image coordinates
    [x_out, y_out] = image2pixel('pano', altb, azb, H, W, nan, nan, 0);
    % Warping image
    [V, U] = meshgrid(1:size(I, 2), 1:size(I, 1));
    Rout = interp2(V, U, I(:, :, 1), x_out, y_out, 'cubic');
    Gout = interp2(V, U, I(:, :, 2), x_out, y_out, 'cubic');
    Bout = interp2(V, U, I(:, :, 3), x_out, y_out, 'cubic');
    Rout(D==0) = 0; Gout(D==0) = 0; Bout(D==0) = 0;
    Iout = cat(3, Rout, Gout, Bout);
    toc;
return

function [Iout, Dout] = blend(I1, I2, D1, D2, leftright)
    % This function blends images generated from different sources
    tic;
    fprintf('Blending output images...\t');
    
    K = ones(3);
    I1(repmat(imdilate(sum(I1, 3)==0, K), [1, 1, 3])) = 0;
    I2(repmat(imdilate(sum(I2, 3)==0, K), [1, 1, 3])) = 0;
    D1(imdilate(D1==0, K)) = 0;
    D2(imdilate(D2==0, K)) = 0;
    
    D1(D1==0)=inf;
    D2(D2==0)=inf;
    idx1 = repmat(D1+0.03<D2, [1, 1, 3]);
    idx2 = repmat(D2+0.03<D1, [1, 1, 3]);
    idx0 = ~(idx1|idx2);
    Iout = zeros(size(I1));
    Dout = zeros(size(D1));
    Iout(idx1) = I1(idx1);
    Dout(idx1(:, :, 1)) = D1(idx1(:, :, 1));
    Iout(idx2) = I2(idx2);
    Dout(idx2(:, :, 1)) = D2(idx2(:, :, 1));
    if strcmp(leftright, 'left')
        Iout(idx0) = I1(idx0);
        Dout(idx0(:, :, 1)) = D1(idx0(:, :, 1));
    elseif strcmp(leftright, 'right')
        Iout(idx0) = I2(idx0);
        Dout(idx0(:, :, 1)) = D2(idx0(:, :, 1));
    else
        g = 2.2;
        Iout(idx0) = ((I1(idx0).^g+I2(idx0).^g)/2).^(1/g);
        Dout(idx0(:, :, 1)) = (D1(idx0(:, :, 1))+D2(idx0(:, :, 1)))/2;
    end
    Dout(Dout==inf) = 0;
    toc;
return

% function [Iout, Dout] = blend(I1, I2, D1, D2, leftright)
%     % This function blends images generated from different sources
%     tic;
%     fprintf('Blending output images...\t');
%     
%     K = ones(3);
%     I1(repmat(imdilate(sum(I1, 3)==0, K), [1, 1, 3])) = 0;
%     I2(repmat(imdilate(sum(I2, 3)==0, K), [1, 1, 3])) = 0;
%     D1(imdilate(D1==0, K)) = 0;
%     D2(imdilate(D2==0, K)) = 0;
%     
%     D1(D1==0)=inf;
%     D2(D2==0)=inf;
%     
%     ratio = zeros(size(D1));
%     ratio(D1<D2) = 1;
%     ratio(D1>D2) = 0;
%     ratio(abs(D1-D2)<0.03) = 0.5;
%     ratio = imgaussfilt(ratio, 6);
%     ratio = repmat(ratio, [1, 1, 3]);
%     g = 2.2;
%     Iout = ((I1.^g) .* ratio + (I2.^g) .* (1-ratio)).^(1/g);
%     Dout = D1 .* ratio(:, :, 1) + D2 .* (1-ratio);
%     
%     Dout(Dout==inf) = 0;
%     toc;
% return