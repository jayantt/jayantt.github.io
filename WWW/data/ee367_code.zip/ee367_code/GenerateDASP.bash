#!/usr/bin/env bash

./bin/TestRenderStereoPanorama --src_intrinsic_param_file ./res/config/sunex_intrinsic.xml \
--ring_rectify_file ./res/config/rectify.yml \
--rig_json_file ./res/config/17cmosis_default.json \
--imgs_dir ./sample_dataset/vid/000000/isp_out \
--output_data_dir ./sample_dataset/vid/000000 \
--prev_frame_data_dir NONE \
--output_equirect_path ./sample_dataset/eqr_frames/eqr_000000.png \
--output_flow_equirect_path ./sample_dataset/eqr_frames/eqrflow_000000.png \
--polar_flow_alg pixflow_low \
--poleremoval_flow_alg pixflow_low \
--cubemap_width 0 \
--cubemap_height 0 \
--eqr_width 6300 \
--eqr_height 3072 \
--final_eqr_width 6144 \
--final_eqr_height 6144 \
--interpupilary_dist 24 \
--zero_parallax_dist 10000 \
--sharpenning 0.25  \
--enable_render_coloradjust \
--enable_top \
--enable_bottom \
--enable_pole_removal \
--bottom_pole_masks_dir ./res/pole_masks
